package com.ethergear.launcher

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.min

/** One slot on the home grid: either an app or a folder. */
sealed interface HomeItem {
    val token: String
}

class AppItem(val entry: AppEntry) : HomeItem {
    override val token: String get() = entry.pkg
}

class FolderItem(val folder: Folder, val members: List<AppEntry>) : HomeItem {
    override val token: String get() = "f:" + folder.id
}

/** The glass tile with up to four mini icons inside. */
@Composable
fun FolderGlyph(item: FolderItem, prefs: Prefs, modifier: Modifier = Modifier) {
    val shape = IconShapes[prefs.shape.coerceIn(IconShapes.indices)].second
    val tile = prefs.iconSize.dp
    Column(
        modifier.size(tile).glass(shape).padding(tile * 0.1f),
        verticalArrangement = Arrangement.SpaceEvenly,
    ) {
        for (row in 0..1) {
            Row(
                Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                for (col in 0..1) {
                    val m = item.members.getOrNull(row * 2 + col)
                    Box(Modifier.weight(1f).fillMaxHeight().padding(1.5.dp)) {
                        if (m != null) {
                            Image(m.icon, null, Modifier.fillMaxSize().clip(RoundedCornerShape(percent = 30)))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FolderCell(
    item: FolderItem,
    prefs: Prefs,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .springClick(onLongClick = onLongClick, onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        FolderGlyph(item, prefs)
        if (prefs.showLabels) {
            GText(
                item.folder.name, 11.sp, FontWeight.Medium,
                Modifier.padding(top = 5.dp).widthIn(max = 76.dp),
                color = Color.White, shadow = true, align = TextAlign.Center,
            )
        }
    }
}

/** The open-folder panel. Scrim and pop-in animation live in App.kt. */
@Composable
fun FolderPanel(vm: LauncherViewModel, id: String) {
    val g = LocalGlass.current
    val prefs = vm.prefs
    val folder = prefs.folders[id] ?: return
    val members = remember(folder, vm.appMap, prefs.effHidden) {
        folder.apps.mapNotNull { vm.appMap[it] }.filter { it.pkg !in prefs.effHidden }
    }
    var name by remember(id) { mutableStateOf(folder.name) }

    Column(
        Modifier
            .fillMaxWidth(0.88f)
            .widthIn(max = 400.dp)
            .glass(RoundedCornerShape(34.dp))
            .springClick(1f) { }
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        BasicTextField(
            value = name,
            onValueChange = {
                name = it.take(24)
                vm.renameFolder(id, name)
            },
            singleLine = true,
            textStyle = TextStyle(
                color = g.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center, fontFamily = LocalFont.current,
            ),
            cursorBrush = SolidColor(g.accent),
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(min(prefs.columns, 4)),
            modifier = Modifier.heightIn(max = 360.dp),
        ) {
            itemsIndexed(members, key = { _, e -> e.pkg }) { i, e ->
                Box(
                    Modifier.padding(vertical = 8.dp).reveal(i / 4 + i % 4),
                    contentAlignment = Alignment.Center,
                ) {
                    AppCell(
                        e, prefs, true,
                        onLongClick = { vm.menu = e },
                        afterLaunch = { vm.openFolder = null },
                    )
                }
            }
        }
    }
}

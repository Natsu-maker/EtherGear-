package com.ethergear.launcher

import android.app.Application
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.graphics.Canvas as AndroidCanvas

enum class AppCategory(val title: String) {
    Games("Games"), Social("Social"), Media("Media"), Tools("Tools"), Other("Other")
}

class AppEntry(
    val pkg: String,
    val label: String,
    val component: ComponentName,
    val category: AppCategory,
    val icon: ImageBitmap,
    val system: Boolean = false,
)

object AppLoader {
    private const val ICON = 144

    fun load(app: Application): List<AppEntry> {
        val pm = app.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<AppEntry>()
        for (ri in pm.queryIntentActivities(q, 0)) {
            val ai = ri.activityInfo
            if (ai.packageName == app.packageName) continue
            try {
                val label = ri.loadLabel(pm).toString()
                val icon = iconBitmap(ri.loadIcon(pm)).asImageBitmap()
                out.add(
                    AppEntry(
                        ai.packageName, label, ComponentName(ai.packageName, ai.name),
                        categorize(ai.applicationInfo, ai.packageName), icon,
                        (ai.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    )
                )
            } catch (_: Throwable) {
            }
        }
        return out.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
    }

    /** Draws adaptive icons WITHOUT the system mask so our own icon shape can be applied. */
    fun iconBitmap(d: Drawable, s: Int = ICON): Bitmap {
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = AndroidCanvas(bmp)
        if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
            val off = (s * 0.25f).toInt()
            d.background?.let { it.setBounds(-off, -off, s + off, s + off); it.draw(c) }
            d.foreground?.let { it.setBounds(-off, -off, s + off, s + off); it.draw(c) }
        } else {
            d.setBounds(0, 0, s, s)
            d.draw(c)
        }
        return bmp
    }

    private fun categorize(info: ApplicationInfo, pkg: String): AppCategory {
        when (info.category) {
            ApplicationInfo.CATEGORY_GAME -> return AppCategory.Games
            ApplicationInfo.CATEGORY_SOCIAL -> return AppCategory.Social
            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO,
            ApplicationInfo.CATEGORY_IMAGE -> return AppCategory.Media
            ApplicationInfo.CATEGORY_PRODUCTIVITY, ApplicationInfo.CATEGORY_MAPS,
            ApplicationInfo.CATEGORY_NEWS -> return AppCategory.Tools
        }
        if ((info.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return AppCategory.Games
        val p = pkg.lowercase()
        fun has(vararg k: String) = k.any { p.contains(it) }
        return when {
            has("game", "supercell", "roblox", "gameloft", "mojang", "pubg", "tencent.ig") -> AppCategory.Games
            has("whatsapp", "telegram", "instagram", "facebook", "discord", "snapchat", "twitter", "reddit", "messenger", "signal") -> AppCategory.Social
            has("music", "spotify", "youtube", "video", "photo", "gallery", "camera", "player", "netflix") -> AppCategory.Media
            has("settings", "calculator", "clock", "file", "notes", "contacts", "dialer", "calendar", "maps", "chrome", "browser", "drive", "mail", "docs", "translate") -> AppCategory.Tools
            else -> AppCategory.Other
        }
    }
}

class LauncherViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)

    var apps by mutableStateOf<List<AppEntry>>(emptyList())
    var drawerOpen by mutableStateOf(false)
    var settingsOpen by mutableStateOf(false)
    var menu by mutableStateOf<AppEntry?>(null)
    var homeSignal by mutableIntStateOf(0)
    var fontTick by mutableIntStateOf(0)

    // Finger-following drawer: while dragging, dragP (0 closed .. 1 open) drives the animation.
    var dragging by mutableStateOf(false)
    var dragP by mutableFloatStateOf(0f)
    // 0..1 position across home pages, used for wallpaper parallax.
    var pageFrac by mutableFloatStateOf(0.5f)

    // Default-launcher prompt state.
    var isDefault by mutableStateOf(false)
    var promptReady by mutableStateOf(false)
    var promptDismissed by mutableStateOf(false)

    fun checkDefault() {
        isDefault = isDefaultLauncher(getApplication())
        resumeTick++
    }

    val appMap by derivedStateOf { apps.associateBy { it.pkg } }
    val visibleApps by derivedStateOf { apps.filter { it.pkg !in prefs.effHidden } }

    fun refresh() {
        viewModelScope.launch(Dispatchers.Default) {
            val list = AppLoader.load(getApplication())
            withContext(Dispatchers.Main) {
                apps = list
                seedIfNeeded(list)
            }
        }
    }

    var editMode by mutableStateOf(false)
    var bloatOpen by mutableStateOf(false)
    var bloatMode by mutableIntStateOf(0) // 0 = hide list, 1 = focus list
    var focusSearch by mutableStateOf(false)
    var openFolder by mutableStateOf<String?>(null)
    var resumeTick by mutableIntStateOf(0)
    var pagerReset by mutableIntStateOf(0)

    fun goHome() {
        // Only replay the intro animations if something was open; a plain Home press stays calm.
        val busy = drawerOpen || settingsOpen || bloatOpen || menu != null || editMode || openFolder != null
        drawerOpen = false
        settingsOpen = false
        bloatOpen = false
        menu = null
        editMode = false
        openFolder = null
        pagerReset++
        if (busy) homeSignal++
    }

    private fun resolvePkg(intent: Intent, known: Set<String>): String? {
        val pm = getApplication<Application>().packageManager
        val pkg = try {
            pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        } catch (_: Exception) {
            null
        }
        return pkg?.takeIf { it != "android" && it in known }
    }

    private fun seedIfNeeded(list: List<AppEntry>) {
        if (prefs.seeded || list.isEmpty()) return
        val known = list.map { it.pkg }.toSet()
        val dock = listOfNotNull(
            resolvePkg(Intent(Intent.ACTION_DIAL), known),
            resolvePkg(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")), known),
            resolvePkg(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")), known),
            resolvePkg(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), known),
        ).distinct()
        prefs.updateDock(dock)
        prefs.updateHome(list.map { it.pkg }.filter { it !in dock }.take(12))
        prefs.markSeeded()
    }

    private fun stripFromFolders(pkg: String, folders: Map<String, Folder>): Map<String, Folder> =
        folders.mapValues { (_, f) -> if (pkg in f.apps) Folder(f.id, f.name, f.apps - pkg) else f }

    /** Drops empty folders and dissolves one-app folders back onto the grid. */
    private fun normalize(tokens: List<String>, folders: Map<String, Folder>) {
        val outTokens = ArrayList<String>()
        val outFolders = LinkedHashMap<String, Folder>()
        for (t in tokens) {
            if (t.startsWith("f:")) {
                val f = folders[t.removePrefix("f:")] ?: continue
                when {
                    f.apps.isEmpty() -> {}
                    f.apps.size == 1 -> outTokens.add(f.apps[0])
                    else -> {
                        outTokens.add(t)
                        outFolders[f.id] = f
                    }
                }
            } else {
                outTokens.add(t)
            }
        }
        prefs.updateFolders(outFolders)
        prefs.updateHome(outTokens)
    }

    fun addHome(pkg: String) {
        val folders = stripFromFolders(pkg, prefs.folders)
        val tokens = if (pkg in prefs.homeApps) prefs.homeApps else prefs.homeApps + pkg
        normalize(tokens, folders)
    }

    fun removeHome(pkg: String) = normalize(prefs.homeApps - pkg, stripFromFolders(pkg, prefs.folders))

    fun isInFolder(pkg: String): Boolean = prefs.folders.values.any { pkg in it.apps }

    /** Moves a grid item so it lands at the given (visible) position. */
    fun moveHomeItem(token: String, toVisibleIndex: Int, visibleTokens: List<String>) {
        val tokens = prefs.homeApps.toMutableList()
        if (!tokens.remove(token)) return
        val vis = visibleTokens.toMutableList()
        vis.remove(token)
        val anchor = vis.getOrNull(toVisibleIndex)
        val at = if (anchor == null) tokens.size else tokens.indexOf(anchor).let { if (it < 0) tokens.size else it }
        tokens.add(at, token)
        prefs.updateHome(tokens)
    }

    /** Drop an app onto another app (makes a folder) or onto a folder (adds to it). */
    fun mergeIntoFolder(draggedPkg: String, targetToken: String) {
        val tokens = prefs.homeApps.toMutableList()
        if (draggedPkg !in tokens || targetToken == draggedPkg) return
        if (targetToken.startsWith("f:")) {
            val id = targetToken.removePrefix("f:")
            val f = prefs.folders[id] ?: return
            tokens.remove(draggedPkg)
            normalize(tokens, prefs.folders + (id to Folder(id, f.name, (f.apps + draggedPkg).distinct())))
        } else {
            if (targetToken !in tokens) return
            val id = "f" + System.currentTimeMillis().toString(36)
            tokens.remove(draggedPkg)
            val at = tokens.indexOf(targetToken)
            if (at < 0) return
            tokens[at] = "f:$id"
            normalize(tokens, prefs.folders + (id to Folder(id, "Folder", listOf(targetToken, draggedPkg))))
        }
    }

    fun renameFolder(id: String, name: String) {
        val f = prefs.folders[id] ?: return
        prefs.updateFolders(prefs.folders + (id to Folder(id, name, f.apps)))
    }

    fun lockApp(pkg: String) = prefs.updateLocked(prefs.locked + pkg)
    fun unlockApp(pkg: String) = prefs.updateLocked(prefs.locked - pkg)
    fun addGame(pkg: String) = prefs.updateGames(prefs.games + pkg)
    fun removeGame(pkg: String) = prefs.updateGames(prefs.games - pkg)

    fun resetLayout() {
        prefs.updateFolders(emptyMap())
        prefs.updateHome(emptyList())
        prefs.updateDock(emptyList())
        prefs.unseed()
        seedIfNeeded(apps)
    }

    fun moveHome(pkg: String, delta: Int) {
        val l = prefs.homeApps.toMutableList()
        val i = l.indexOf(pkg)
        val j = i + delta
        if (i < 0 || j < 0 || j >= l.size) return
        val t = l[i]; l[i] = l[j]; l[j] = t
        prefs.updateHome(l)
    }

    fun addDock(pkg: String) {
        if (pkg in prefs.dock) return
        val d = prefs.dock.toMutableList()
        if (d.size >= 5) d.removeAt(d.size - 1)
        d.add(pkg)
        prefs.updateDock(d)
    }

    fun removeDock(pkg: String) = prefs.updateDock(prefs.dock - pkg)
    fun hideMany(pkgs: Collection<String>) = prefs.updateHidden(prefs.hidden + pkgs)
    fun showMany(pkgs: Collection<String>) = prefs.updateHidden(prefs.hidden - pkgs.toSet())
    fun hide(pkg: String) = prefs.updateHidden(prefs.hidden + pkg)
    fun unhide(pkg: String) = prefs.updateHidden(prefs.hidden - pkg)
}

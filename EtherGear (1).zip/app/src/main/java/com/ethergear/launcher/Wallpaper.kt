package com.ethergear.launcher

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import kotlin.math.max
import kotlin.math.min
import android.graphics.Canvas as AndroidCanvas

/**
 * sharp   = the wallpaper, fitted to the screen (home background)
 * blurred = tiny, heavily blurred copy used behind every glass panel (works on Android 10,
 *           which has no real-time blur)
 */
class Backdrop(val sharp: ImageBitmap, val blurred: ImageBitmap, val w: Int, val h: Int)

object WallpaperEngine {
    private const val FILE = "wallpaper.jpg"

    fun build(ctx: Context, w: Int, h: Int): Backdrop? {
        if (w <= 0 || h <= 0) return null
        val app = ctx.applicationContext
        val src: Bitmap = try {
            loadPicked(app) ?: loadSystem(app, w, h) ?: generated(w, h)
        } catch (_: Throwable) {
            generated(w, h)
        }
        val fitted = centerCrop(src, w, h)
        saveCache(app, fitted)
        val small = Bitmap.createScaledBitmap(fitted, max(1, w / 24), max(1, h / 24), true)
        val blurred = boxBlur(small, 2, 2)
        return Backdrop(fitted.asImageBitmap(), blurred.asImageBitmap(), w, h)
    }

    fun savePicked(ctx: Context, uri: Uri, w: Int, h: Int): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val target = max(w, h) * 2
            while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= target) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false
            File(ctx.filesDir, FILE).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            true
        } catch (_: Throwable) {
            false
        }
    }

    /** Small copy used as the window background so a flash always shows YOUR wallpaper. */
    private fun saveCache(ctx: Context, fitted: Bitmap) {
        try {
            val s = Bitmap.createScaledBitmap(fitted, max(1, fitted.width / 3), max(1, fitted.height / 3), true)
            File(ctx.filesDir, "bgcache.jpg").outputStream().use { s.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        } catch (_: Throwable) {
        }
    }

    fun loadCache(ctx: Context): Bitmap? = try {
        val f = File(ctx.filesDir, "bgcache.jpg")
        if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    } catch (_: Throwable) {
        null
    }

    fun clearPicked(ctx: Context) {
        File(ctx.filesDir, FILE).delete()
    }

    private fun loadPicked(ctx: Context): Bitmap? {
        val f = File(ctx.filesDir, FILE)
        return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    }

    private fun loadSystem(ctx: Context, w: Int, h: Int): Bitmap? {
        return try {
            val d = WallpaperManager.getInstance(ctx).drawable ?: return null
            val dw = d.intrinsicWidth.coerceAtLeast(1)
            val dh = d.intrinsicHeight.coerceAtLeast(1)
            val scale = min(1f, (max(w, h) * 1.5f) / max(dw, dh))
            d.toBitmap(max(1, (dw * scale).toInt()), max(1, (dh * scale).toInt()))
        } catch (_: Throwable) {
            null
        }
    }

    /** Built-in fallback: a dark ether-glow gradient. */
    private fun generated(w: Int, h: Int): Bitmap {
        val sw = max(w / 4, 64)
        val sh = max(h / 4, 64)
        val bmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        val c = AndroidCanvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            0f, 0f, sw.toFloat(), sh.toFloat(),
            intArrayOf(0xFF050714.toInt(), 0xFF120A33.toInt(), 0xFF04202C.toInt()),
            null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, sw.toFloat(), sh.toFloat(), p)
        p.shader = RadialGradient(
            sw * 0.15f, sh * 0.2f, sw * 0.9f,
            intArrayOf(0x884FD8FF.toInt(), 0x004FD8FF), null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, sw.toFloat(), sh.toFloat(), p)
        p.shader = RadialGradient(
            sw * 0.95f, sh * 0.85f, sw * 1.0f,
            intArrayOf(0x889D7BFF.toInt(), 0x009D7BFF), null, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, sw.toFloat(), sh.toFloat(), p)
        return Bitmap.createScaledBitmap(bmp, w, h, true)
    }

    private fun centerCrop(src: Bitmap, w: Int, h: Int): Bitmap {
        val scale = max(w.toFloat() / src.width, h.toFloat() / src.height)
        val cw = min(src.width, max(1, (w / scale).toInt()))
        val ch = min(src.height, max(1, (h / scale).toInt()))
        val left = ((src.width - cw) / 2).coerceAtLeast(0)
        val top = ((src.height - ch) / 2).coerceAtLeast(0)
        val cropped = Bitmap.createBitmap(src, left, top, cw, ch)
        return Bitmap.createScaledBitmap(cropped, w, h, true)
    }

    private fun boxBlur(bmp: Bitmap, radius: Int, passes: Int): Bitmap {
        val w = bmp.width
        val h = bmp.height
        var a = IntArray(w * h)
        bmp.getPixels(a, 0, w, 0, 0, w, h)
        var b = IntArray(w * h)
        repeat(passes) {
            blurPass(a, b, w, h, radius, true)
            blurPass(b, a, w, h, radius, false)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, w, 0, 0, w, h)
        return out
    }

    private fun blurPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val lines = if (horizontal) h else w
        val len = if (horizontal) w else h
        val div = 2 * r + 1
        for (line in 0 until lines) {
            fun at(i: Int): Int {
                val c = i.coerceIn(0, len - 1)
                return if (horizontal) line * w + c else c * w + line
            }
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val p = src[at(i)]
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
            }
            for (i in 0 until len) {
                dst[at(i)] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[at(i + r + 1)]
                val rem = src[at(i - r)]
                sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                sb += (add and 255) - (rem and 255)
            }
        }
    }
}

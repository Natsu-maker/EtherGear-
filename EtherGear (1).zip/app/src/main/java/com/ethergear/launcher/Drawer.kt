@file:OptIn(ExperimentalFoundationApi::class)

package com.ethergear.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private fun initials(label: String): String =
    label.split(Regex("[^A-Za-z0-9]+")).filter { it.isNotEmpty() }.joinToString("") { it.take(1) }.lowercase()

@Composable
fun DrawerLayer(vm: LauncherViewModel, compact: Boolean = false) {
    val g = LocalGlass.current
    val bd = LocalBackdrop.current
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    val auth = LocalAuth.current
    val prefs = vm.prefs
    val screenH = LocalConfiguration.current.screenHeightDp * LocalDensity.current.density
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<AppCategory?>(null) }

    // Drop the keyboard as soon as the drawer starts closing.
    LaunchedEffect(vm.drawerOpen) { if (!vm.drawerOpen) focus.clearFocus() }

    // "Swipe down = app search" focuses the search box as the drawer opens.
    val fr = remember { FocusRequester() }
    LaunchedEffect(vm.focusSearch) {
        if (vm.focusSearch) {
            delay(280)
            try {
                fr.requestFocus()
            } catch (_: Exception) {
            }
            vm.focusSearch = false
        }
    }

    BackHandler(enabled = query.isNotEmpty() || cat != null) {
        query = ""
        cat = null
    }

    val q = query.trim().lowercase()
    val visible = vm.visibleApps
    val shown = remember(visible, q, cat) {
        visible
            .filter {
                (cat == null || it.category == cat) &&
                    (q.isEmpty() || it.label.lowercase().contains(q) || initials(it.label).startsWith(q))
            }
            .sortedBy { if (q.isNotEmpty() && !it.label.lowercase().startsWith(q)) 1 else 0 }
    }
    val categories = remember(visible) {
        AppCategory.values().filter { c -> visible.any { it.category == c } }
    }
    val cols = if (compact) prefs.columns.coerceAtMost(5) else prefs.columns

    // Blocks touches from reaching the home screen underneath.
    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }) {
        if (!compact) {
            if (bd != null) {
                Image(
                    bd.blurred, null, Modifier.fillMaxSize(),
                    contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.Low,
                )
            }
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (g.dark) 0.5f else 0.3f)))
        }

        Column(
            Modifier
                .fillMaxSize()
                .then(
                    if (compact) Modifier.windowInsetsPadding(WindowInsets.ime)
                    else Modifier.statusBarsPadding()
                        .windowInsetsPadding(WindowInsets.navigationBars.union(WindowInsets.ime))
                )
        ) {
            // Header: dragging it down pulls the drawer closed, following your finger.
            Column(
                Modifier.pointerInput(compact) {
                    if (compact) return@pointerInput
                    var acc = 0f
                    detectVerticalDragGestures(
                        onDragStart = { acc = 0f },
                        onDragCancel = { if (vm.dragging) vm.dragging = false },
                        onDragEnd = {
                            if (vm.dragging) {
                                vm.drawerOpen = vm.dragP > 0.6f
                                vm.dragging = false
                            }
                        },
                    ) { _, dy ->
                        acc += dy
                        if (acc > 0f || vm.dragging) {
                            vm.dragging = true
                            vm.dragP = (1f - acc.coerceAtLeast(0f) / (screenH * 0.5f)).coerceIn(0f, 1f)
                        }
                    }
                }
            ) {
                Row(
                    Modifier
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                        .reveal(0)
                        .fillMaxWidth()
                        .height(52.dp)
                        .glass(RoundedCornerShape(26.dp))
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    SearchGlyph(g.subtext, Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) GText("Search apps", 16.sp, color = g.subtext)
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = TextStyle(color = g.text, fontSize = 16.sp, fontFamily = LocalFont.current),
                            cursorBrush = SolidColor(g.accent),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {
                                if (shown.size == 1) {
                                    val e = shown[0]
                                    val go = {
                                        launchApp(ctx, e)
                                        vm.drawerOpen = false
                                    }
                                    if (e.pkg in prefs.locked) auth("Unlock ${e.label}", go) else go()
                                }
                            }),
                            modifier = Modifier.fillMaxWidth().focusRequester(fr),
                        )
                    }
                    Box(
                        Modifier.size(34.dp).springClick { vm.settingsOpen = true },
                        contentAlignment = Alignment.Center,
                    ) { SlidersGlyph(g.text, Modifier.size(20.dp)) }
                }

                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    GChip("All", cat == null, Modifier.reveal(1)) { cat = null }
                    categories.forEachIndexed { i, c ->
                        GChip(c.title, cat == c, Modifier.reveal(2 + i)) { cat = c }
                    }
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(cols),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 12.dp),
            ) {
                itemsIndexed(shown, key = { _, e -> e.pkg }) { i, e ->
                    Box(
                        Modifier
                            .animateItemPlacement()
                            .padding(vertical = 10.dp)
                            .reveal(2 + i / cols + i % cols, enabled = i < 28),
                        contentAlignment = Alignment.Center,
                    ) {
                        AppCell(
                            e, prefs, true,
                            onLongClick = { vm.menu = e },
                            afterLaunch = { vm.drawerOpen = false },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuRow(text: String, index: Int, danger: Boolean = false, onClick: () -> Unit) {
    val g = LocalGlass.current
    Box(
        Modifier
            .reveal(index)
            .fillMaxWidth()
            .springClick(0.97f, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 13.dp)
    ) {
        GText(text, 15.sp, FontWeight.Medium, color = if (danger) Color(0xFFFF6B7A) else g.text)
    }
}

/** The long-press panel. The dimming scrim and the pop-in animation live in App.kt. */
@Composable
fun MenuPanel(entry: AppEntry, vm: LauncherViewModel) {
    val ctx = LocalContext.current
    val auth = LocalAuth.current
    val prefs = vm.prefs
    val inHome = entry.pkg in prefs.homeApps
    val inFolder = vm.isInFolder(entry.pkg)
    val inDock = entry.pkg in prefs.dock
    val locked = entry.pkg in prefs.locked
    val isGame = entry.pkg in prefs.games

    fun act(block: () -> Unit): () -> Unit = {
        block()
        vm.menu = null
    }

    Column(
        Modifier
            .fillMaxWidth(0.85f)
            .widthIn(max = 340.dp)
            .heightIn(max = 560.dp)
            .glass(RoundedCornerShape(30.dp))
            .springClick(1f) { }
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
    ) {
        Row(Modifier.padding(10.dp).reveal(0), verticalAlignment = Alignment.CenterVertically) {
            val shape = IconShapes[prefs.shape.coerceIn(IconShapes.indices)].second
            Image(entry.icon, entry.label, Modifier.size(44.dp).clip(shape))
            Spacer(Modifier.width(12.dp))
            GText(entry.label, 17.sp, FontWeight.SemiBold)
        }
        var n = 1
        if (inFolder) {
            MenuRow("Move out of folder", n++, onClick = act { vm.addHome(entry.pkg) })
        } else if (!inHome) {
            MenuRow("Add to home", n++, onClick = act { vm.addHome(entry.pkg) })
        } else {
            MenuRow("Remove from home", n++, onClick = act { vm.removeHome(entry.pkg) })
            MenuRow("Move earlier", n++, onClick = { vm.moveHome(entry.pkg, -1) })
            MenuRow("Move later", n++, onClick = { vm.moveHome(entry.pkg, 1) })
        }
        MenuRow("Rearrange home", n++, onClick = act {
            vm.drawerOpen = false
            vm.openFolder = null
            vm.editMode = true
        })
        if (!inDock) MenuRow("Add to dock", n++, onClick = act { vm.addDock(entry.pkg) })
        else MenuRow("Remove from dock", n++, onClick = act { vm.removeDock(entry.pkg) })
        if (locked) {
            MenuRow("Unlock app", n++, onClick = act {
                auth("Remove the lock from ${entry.label}") { vm.unlockApp(entry.pkg) }
            })
        } else {
            MenuRow("Lock app", n++, onClick = act { vm.lockApp(entry.pkg) })
        }
        if (isGame) MenuRow("Remove from game shelf", n++, onClick = act { vm.removeGame(entry.pkg) })
        else MenuRow("Add to game shelf", n++, onClick = act { vm.addGame(entry.pkg) })
        MenuRow("Hide app", n++, onClick = act { vm.hide(entry.pkg) })
        MenuRow("App info", n++, onClick = act { openAppInfo(ctx, entry) })
        MenuRow("Uninstall", n, danger = true, onClick = act { uninstallApp(ctx, entry) })
    }
}

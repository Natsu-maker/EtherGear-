# EtherGear v1.1

Glass-style Android launcher (Kotlin + Jetpack Compose). Min Android 8.0, tuned for Android 10.

## Build from a phone (GitHub Actions)
1. Keep your existing `.github/workflows/build.yml` (it builds the optimized release APK).
2. Upload the new `EtherGear.zip` (do NOT unzip it), replacing the old one, and commit.
3. Open the Actions tab and wait for "Build EtherGear APK" to finish.
4. Open the repo's Releases page, tap the newest `EtherGear.apk`, install over the old one.

## One-time permissions (all optional, all from Settings > Features)
- Notification access: badges + music widget
- Accessibility "EtherGear double-tap lock": double-tap empty space to lock the screen
- Usage access: weekly playtime on the game shelf

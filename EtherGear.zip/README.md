# EtherGear v0.1

Glass-style Android launcher (Kotlin + Jetpack Compose). Min Android 8.0, tuned for Android 10.

## Build from a phone (GitHub Actions)
1. Create a new repo on github.com (free account is fine).
2. Add file -> Create new file, name it `.github/workflows/build.yml`, paste the contents of build.yml, commit.
3. Add file -> Upload files, upload `EtherGear.zip` (do NOT unzip it), commit.
4. Open the Actions tab and wait for "Build EtherGear APK" to finish (about 5-8 minutes the first time).
5. Open the repo's Releases page, tap `EtherGear.apk`, install it (allow "install unknown apps").
6. Press Home and choose EtherGear -> Always.

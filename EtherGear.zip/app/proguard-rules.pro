# EtherGear R8 rules. Compose and AndroidX ship their own consumer rules.
-dontwarn java.lang.invoke.StringConcatFactory

@file:OptIn(ExperimentalLayoutApi::class)

package com.ethergear.launcher

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val g = LocalGlass.current
    Column(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(26.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        GText(title.uppercase(), 12.sp, FontWeight.SemiBold, color = g.accent, letterSpacing = 1.4.sp)
        content()
    }
}

@Composable
private fun ChipRow(content: @Composable () -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) { content() }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    val g = LocalGlass.current
    Column {
        GText(label, 14.sp, FontWeight.Medium, color = g.subtext)
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = g.accent,
                activeTrackColor = g.accent,
                inactiveTrackColor = g.text.copy(alpha = 0.2f),
            ),
        )
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val g = LocalGlass.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        GText(label, 15.sp, FontWeight.Medium, Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = g.accent,
                checkedThumbColor = Color.White,
                uncheckedTrackColor = g.text.copy(alpha = 0.2f),
                uncheckedThumbColor = g.text.copy(alpha = 0.7f),
                uncheckedBorderColor = Color.Transparent,
            ),
        )
    }
}

@Composable
fun SettingsLayer(vm: LauncherViewModel) {
    val g = LocalGlass.current
    val bd = LocalBackdrop.current
    val ctx = LocalContext.current
    val prefs = vm.prefs
    val scope = rememberCoroutineScope()
    var fonts by remember { mutableStateOf(FontStore.list(ctx)) }

    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = FontStore.import(ctx, uri)
            if (name == null) {
                Toast.makeText(ctx, "That doesn't look like a .ttf or .otf font file", Toast.LENGTH_LONG).show()
            } else {
                fonts = FontStore.list(ctx)
                prefs.updateFontMain(name)
                vm.fontTick++
                Toast.makeText(ctx, "Font added: ${name.substringBeforeLast('.')}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val dm = ctx.resources.displayMetrics
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    WallpaperEngine.savePicked(ctx.applicationContext, uri, dm.widthPixels, dm.heightPixels)
                }
                if (ok) prefs.bumpWallpaper()
                else Toast.makeText(ctx, "Couldn't use that image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (bd != null) {
            Image(
                bd.blurred, null, Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds,
                filterQuality = androidx.compose.ui.graphics.FilterQuality.Low,
            )
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (g.dark) 0.55f else 0.3f)))

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    GText("EtherGear", 28.sp, FontWeight.SemiBold, color = Color.White, glow = g.accent.copy(alpha = 0.5f))
                    GText("Settings", 14.sp, color = Color.White.copy(alpha = 0.7f))
                }
                GChip("Done", true) { vm.settingsOpen = false }
            }

            SettingsCard("Glass") {
                ChipRow {
                    GChip("Dark glass", prefs.dark) { prefs.updateDark(true) }
                    GChip("Light glass", !prefs.dark) { prefs.updateDark(false) }
                }
                SliderRow("Glass tint", prefs.tint, 0.1f..0.6f) { prefs.updateTint(it) }
                GText("Accent", 14.sp, FontWeight.Medium, color = g.subtext)
                ChipRow {
                    Accents.forEachIndexed { i, c ->
                        Box(
                            Modifier
                                .size(38.dp)
                                .springClick(0.9f) { prefs.updateAccent(i) }
                                .clip(CircleShape)
                                .background(c)
                                .then(
                                    if (prefs.accent == i) Modifier.border(3.dp, Color.White, CircleShape)
                                    else Modifier
                                )
                        )
                    }
                }
            }

            SettingsCard("Home & icons") {
                GText("Grid columns", 14.sp, FontWeight.Medium, color = g.subtext)
                ChipRow {
                    listOf(4, 5).forEach { n -> GChip("$n", prefs.columns == n) { prefs.updateColumns(n) } }
                }
                GText("Icon shape", 14.sp, FontWeight.Medium, color = g.subtext)
                ChipRow {
                    IconShapes.forEachIndexed { i, s -> GChip(s.first, prefs.shape == i) { prefs.updateShape(i) } }
                }
                SliderRow("Icon size", prefs.iconSize, 44f..72f) { prefs.updateIconSize(it) }
                ToggleRow("Show icon labels", prefs.showLabels) { prefs.updateLabels(it) }
            }

            SettingsCard("Wallpaper") {
                GText(
                    "Pick an image for the home screen. The glass panels blur this exact image.",
                    13.sp, color = g.subtext, maxLines = 3,
                )
                ChipRow {
                    GChip("Choose wallpaper", false) { wallpaperPicker.launch(arrayOf("image/*")) }
                    GChip("Use default", false) {
                        WallpaperEngine.clearPicked(ctx.applicationContext)
                        prefs.bumpWallpaper()
                    }
                }
            }

            SettingsCard("Fonts") {
                GText(
                    "Download any .ttf or .otf font (Google Fonts, dafont, etc.), then tap Import and pick the file.",
                    13.sp, color = g.subtext, maxLines = 3,
                )
                GText("Main font", 14.sp, FontWeight.Medium, color = g.subtext)
                ChipRow {
                    GChip("System", prefs.fontMain.isEmpty()) { prefs.updateFontMain("") }
                    fonts.forEach { f ->
                        GChip(f.substringBeforeLast('.'), prefs.fontMain == f) { prefs.updateFontMain(f) }
                    }
                }
                GText("Clock font", 14.sp, FontWeight.Medium, color = g.subtext)
                ChipRow {
                    GChip("System", prefs.fontClock.isEmpty()) { prefs.updateFontClock("") }
                    fonts.forEach { f ->
                        GChip(f.substringBeforeLast('.'), prefs.fontClock == f) { prefs.updateFontClock(f) }
                    }
                }
                ChipRow {
                    GChip("+ Import font", false) { fontPicker.launch(arrayOf("*/*")) }
                }
                if (fonts.isNotEmpty()) {
                    GText("Remove", 14.sp, FontWeight.Medium, color = g.subtext)
                    ChipRow {
                        fonts.forEach { f ->
                            GChip("Delete ${f.substringBeforeLast('.')}", false) {
                                FontStore.delete(ctx, f)
                                if (prefs.fontMain == f) prefs.updateFontMain("")
                                if (prefs.fontClock == f) prefs.updateFontClock("")
                                fonts = FontStore.list(ctx)
                                vm.fontTick++
                            }
                        }
                    }
                }
            }

            SettingsCard("Hidden apps") {
                val hidden = vm.apps.filter { it.pkg in prefs.hidden }
                if (hidden.isEmpty()) {
                    GText("No hidden apps. Long-press an app and choose Hide.", 13.sp, color = g.subtext, maxLines = 2)
                } else {
                    ChipRow { hidden.forEach { e -> GChip("Unhide ${e.label}", false) { vm.unhide(e.pkg) } } }
                }
            }

            SettingsCard("System") {
                GText(
                    "To use EtherGear as your home screen, set it as the default launcher.",
                    13.sp, color = g.subtext, maxLines = 3,
                )
                ChipRow { GChip("Set as default launcher", false) { openDefaultLauncherSettings(ctx) } }
                GText(
                    "Swipe up: app drawer  ·  Swipe down: notifications  ·  Long-press clock: settings",
                    12.sp, color = g.subtext, maxLines = 3,
                )
            }

            GText("EtherGear v0.1.0", 12.sp, color = Color.White.copy(alpha = 0.5f), modifier = Modifier.padding(bottom = 24.dp))
            Spacer(Modifier.height(8.dp))
        }
    }
}

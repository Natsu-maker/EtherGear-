@file:OptIn(ExperimentalFoundationApi::class)

package com.ethergear.launcher

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

val Accents = listOf(
    Color(0xFF4FD8FF), Color(0xFF9D7BFF), Color(0xFFFF6BD6),
    Color(0xFF5CFFB1), Color(0xFFFFC857), Color(0xFFFF5C6C),
)
val AccentNames = listOf("Ether", "Violet", "Magenta", "Mint", "Amber", "Crimson")

private val Hexagon: Shape = GenericShape { size, _ ->
    val w = size.width
    val h = size.height
    moveTo(w * 0.5f, 0f)
    lineTo(w, h * 0.25f)
    lineTo(w, h * 0.75f)
    lineTo(w * 0.5f, h)
    lineTo(0f, h * 0.75f)
    lineTo(0f, h * 0.25f)
    close()
}

val IconShapes: List<Pair<String, Shape>> = listOf(
    "Circle" to CircleShape,
    "Squircle" to RoundedCornerShape(percent = 34),
    "Rounded" to RoundedCornerShape(percent = 20),
    "Teardrop" to RoundedCornerShape(
        topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 12, bottomStartPercent = 50
    ),
    "Hexagon" to Hexagon,
)

class GlassTheme(val dark: Boolean, val tint: Float, val accent: Color) {
    val text: Color get() = if (dark) Color(0xFFF4F6FF) else Color(0xFF0E1220)
    val subtext: Color get() = text.copy(alpha = 0.62f)
    val tintColor: Color
        get() = if (dark) Color(0xFF0A0D18).copy(alpha = tint) else Color.White.copy(alpha = tint + 0.1f)
}

val LocalGlass = staticCompositionLocalOf { GlassTheme(true, 0.3f, Accents[0]) }
val LocalBackdrop = staticCompositionLocalOf<Backdrop?> { null }
val LocalFont = compositionLocalOf<FontFamily> { FontFamily.Default }
val LocalClockFont = compositionLocalOf<FontFamily> { FontFamily.Default }

/**
 * Frosted-glass surface: samples the pre-blurred wallpaper at the panel's own screen position
 * (so the blur lines up with what is really behind it), adds a tint, a top highlight and a rim light.
 */
fun Modifier.glass(shape: Shape): Modifier = composed {
    val g = LocalGlass.current
    val bd = LocalBackdrop.current
    var pos by remember { mutableStateOf(Offset.Zero) }
    val rim = Brush.linearGradient(
        listOf(
            Color.White.copy(alpha = if (g.dark) 0.38f else 0.85f),
            Color.White.copy(alpha = 0.04f),
            g.accent.copy(alpha = if (g.dark) 0.40f else 0.28f),
        )
    )
    Modifier
        .onGloballyPositioned { pos = it.positionInRoot() }
        .clip(shape)
        .drawBehind {
            if (bd != null) {
                drawImage(
                    bd.blurred,
                    dstOffset = IntOffset((-pos.x).roundToInt(), (-pos.y).roundToInt()),
                    dstSize = IntSize(bd.w, bd.h),
                    filterQuality = FilterQuality.Low,
                )
            }
            drawRect(g.tintColor)
            drawRect(
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.14f), Color.Transparent),
                    endY = size.height * 0.55f
                )
            )
        }
        .border(1.dp, rim, shape)
}

/** Springy press feedback + click + optional long click. */
fun Modifier.springClick(
    pressedScale: Float = 0.9f,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) pressedScale else 1f,
        spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    Modifier
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(
            interactionSource = src,
            indication = null,
            onLongClick = onLongClick,
            onClick = onClick,
        )
}

@Composable
fun GText(
    text: String,
    size: TextUnit = 14.sp,
    weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier,
    color: Color = LocalGlass.current.text,
    clock: Boolean = false,
    maxLines: Int = 1,
    align: TextAlign? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    shadow: Boolean = false,
    glow: Color? = null,
) {
    val family = if (clock) LocalClockFont.current else LocalFont.current
    val sh = when {
        glow != null -> Shadow(glow, Offset.Zero, 28f)
        shadow -> Shadow(Color.Black.copy(alpha = 0.55f), Offset(0f, 2f), 6f)
        else -> null
    }
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = size,
        fontWeight = weight,
        fontFamily = family,
        letterSpacing = letterSpacing,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        textAlign = align,
        style = TextStyle(shadow = sh),
    )
}

@Composable
fun GChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .springClick(0.94f, onClick = onClick)
            .then(
                if (selected) Modifier.clip(shape).background(g.accent.copy(alpha = 0.92f))
                else Modifier.glass(shape)
            )
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        GText(text, 13.sp, FontWeight.Medium, color = if (selected) Color(0xFF06101A) else g.text)
    }
}

@Composable
fun SearchGlyph(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.minDimension
        drawCircle(color, radius = s * 0.30f, center = Offset(s * 0.42f, s * 0.42f), style = Stroke(width = s * 0.1f))
        drawLine(
            color, Offset(s * 0.66f, s * 0.66f), Offset(s * 0.9f, s * 0.9f),
            strokeWidth = s * 0.1f, cap = StrokeCap.Round
        )
    }
}

@Composable
fun SlidersGlyph(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.minDimension
        val sw = s * 0.08f
        val ys = listOf(0.25f, 0.5f, 0.75f)
        val xs = listOf(0.65f, 0.35f, 0.6f)
        for (i in 0..2) {
            drawLine(color, Offset(s * 0.1f, s * ys[i]), Offset(s * 0.9f, s * ys[i]), strokeWidth = sw, cap = StrokeCap.Round)
            drawCircle(color, radius = s * 0.09f, center = Offset(s * xs[i], s * ys[i]))
        }
    }
}

@file:OptIn(ExperimentalFoundationApi::class)

package com.ethergear.launcher

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

val Accents = listOf(
    Color(0xFF4FD8FF), Color(0xFF9D7BFF), Color(0xFFFF6BD6),
    Color(0xFF5CFFB1), Color(0xFFFFC857), Color(0xFFFF5C6C),
)

private val Hexagon: Shape = GenericShape { size, _ ->
    val w = size.width
    val h = size.height
    moveTo(w * 0.5f, 0f)
    lineTo(w, h * 0.25f)
    lineTo(w, h * 0.75f)
    lineTo(w * 0.5f, h)
    lineTo(0f, h * 0.75f)
    lineTo(0f, h * 0.25f)
    close()
}

val IconShapes: List<Pair<String, Shape>> = listOf(
    "Circle" to CircleShape,
    "Squircle" to RoundedCornerShape(percent = 34),
    "Rounded" to RoundedCornerShape(percent = 20),
    "Teardrop" to RoundedCornerShape(
        topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 12, bottomStartPercent = 50
    ),
    "Hexagon" to Hexagon,
)

class GlassTheme(val dark: Boolean, val tint: Float, val accent: Color) {
    val text: Color get() = if (dark) Color(0xFFF4F6FF) else Color(0xFF0E1220)
    val subtext: Color get() = text.copy(alpha = 0.62f)
    val tintColor: Color
        get() = if (dark) Color(0xFF0A0D18).copy(alpha = tint) else Color.White.copy(alpha = tint + 0.1f)
}

val LocalGlass = staticCompositionLocalOf { GlassTheme(true, 0.3f, Accents[0]) }
val LocalBackdrop = staticCompositionLocalOf<Backdrop?> { null }
val LocalFont = compositionLocalOf<FontFamily> { FontFamily.Default }
val LocalClockFont = compositionLocalOf<FontFamily> { FontFamily.Default }

/**
 * Frosted-glass surface. Draws ONLY the slice of the pre-blurred wallpaper that sits behind the
 * panel (cheap), then a tint, a top highlight and a rim light.
 */
fun Modifier.glass(shape: Shape): Modifier = composed {
    val g = LocalGlass.current
    val bd = LocalBackdrop.current
    var pos by remember { mutableStateOf(Offset.Zero) }
    val rim = remember(g.dark, g.accent) {
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = if (g.dark) 0.38f else 0.85f),
                Color.White.copy(alpha = 0.04f),
                g.accent.copy(alpha = if (g.dark) 0.40f else 0.28f),
            )
        )
    }
    Modifier
        .onGloballyPositioned { pos = it.positionInRoot() }
        .clip(shape)
        .drawBehind {
            if (bd != null) {
                val bw = bd.blurred.width.toFloat()
                val bh = bd.blurred.height.toFloat()
                val sx = bw / bd.w
                val sy = bh / bd.h
                val l = pos.x * sx
                val t = pos.y * sy
                val r = l + size.width * sx
                val b = t + size.height * sy
                val cl = max(0f, l)
                val ct = max(0f, t)
                val cr = min(bw, r)
                val cb = min(bh, b)
                if (cr - cl >= 1f && cb - ct >= 1f) {
                    drawImage(
                        bd.blurred,
                        srcOffset = IntOffset(cl.roundToInt(), ct.roundToInt()),
                        srcSize = IntSize((cr - cl).roundToInt().coerceAtLeast(1), (cb - ct).roundToInt().coerceAtLeast(1)),
                        dstOffset = IntOffset(((cl - l) / sx).roundToInt(), ((ct - t) / sy).roundToInt()),
                        dstSize = IntSize(((cr - cl) / sx).roundToInt().coerceAtLeast(1), ((cb - ct) / sy).roundToInt().coerceAtLeast(1)),
                        filterQuality = FilterQuality.Low,
                    )
                }
            }
            drawRect(g.tintColor)
            drawRect(
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.14f), Color.Transparent),
                    endY = size.height * 0.55f
                )
            )
        }
        .border(1.dp, rim, shape)
}

/** Springy press feedback + click + optional long click. */
fun Modifier.springClick(
    pressedScale: Float = 0.9f,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val haptic = LocalHapticFeedback.current
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) pressedScale else 1f,
        spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    Modifier
        .graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(
            interactionSource = src,
            indication = null,
            onLongClick = onLongClick?.let { lc ->
                {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    lc()
                }
            },
            onClick = onClick,
        )
}

/**
 * Entrance animation: pops in with a spring (scale + fade + rise). `index` makes a diagonal
 * wave. Replays whenever `key` changes.
 */
fun Modifier.reveal(index: Int = 0, key: Any = Unit, enabled: Boolean = true): Modifier = composed {
    val p = remember(key) { Animatable(if (enabled) 0f else 1f) }
    LaunchedEffect(key) {
        if (enabled) {
            delay(index.coerceIn(0, 24) * 24L)
            p.animateTo(1f, spring(dampingRatio = 0.68f, stiffness = 240f))
        }
    }
    Modifier.graphicsLayer {
        val v = p.value
        val s = 0.7f + 0.3f * v
        scaleX = s
        scaleY = s
        alpha = v.coerceIn(0f, 1f)
        translationY = (1f - v) * 36.dp.toPx()
    }
}

/** A bright band that sweeps once around the border when `progress` goes 0 -> 1. */
fun Modifier.introShine(progress: () -> Float, corner: Dp = 28.dp, strength: Float = 1f): Modifier = composed {
    val g = LocalGlass.current
    Modifier.drawWithContent {
        drawContent()
        val p = progress()
        if (p > 0.001f && p < 0.999f) {
            val w = size.width
            val x = -w * 0.6f + p * w * 2.2f
            drawRoundRect(
                Brush.linearGradient(
                    listOf(Color.Transparent, g.accent.copy(alpha = 0.95f * strength), Color.White.copy(alpha = 0.9f * strength), Color.Transparent),
                    start = Offset(x, 0f),
                    end = Offset(x + w * 0.45f, size.height),
                ),
                cornerRadius = CornerRadius(corner.toPx()),
                style = Stroke(width = 2.5.dp.toPx()),
            )
        }
    }
}

@Composable
fun GText(
    text: String,
    size: TextUnit = 14.sp,
    weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier,
    color: Color = LocalGlass.current.text,
    clock: Boolean = false,
    maxLines: Int = 1,
    align: TextAlign? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    shadow: Boolean = false,
    glow: Color? = null,
) {
    val family = if (clock) LocalClockFont.current else LocalFont.current
    val sh = when {
        glow != null -> Shadow(glow, Offset.Zero, 28f)
        shadow -> Shadow(Color.Black.copy(alpha = 0.55f), Offset(0f, 2f), 6f)
        else -> null
    }
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = size,
        fontWeight = weight,
        fontFamily = family,
        letterSpacing = letterSpacing,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        textAlign = align,
        style = TextStyle(shadow = sh),
    )
}

@Composable
fun GChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val g = LocalGlass.current
    val shape = RoundedCornerShape(50)
    val fill by animateFloatAsState(if (selected) 1f else 0f, spring(dampingRatio = 0.8f, stiffness = 500f), label = "chipFill")
    val textColor by animateColorAsState(if (selected) Color(0xFF06101A) else g.text, label = "chipText")
    Box(
        modifier
            .springClick(0.94f, onClick = onClick)
            .glass(shape)
            .drawBehind { drawRect(g.accent.copy(alpha = 0.92f * fill)) }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        GText(text, 13.sp, FontWeight.Medium, color = textColor)
    }
}

@Composable
fun SearchGlyph(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.minDimension
        drawCircle(color, radius = s * 0.30f, center = Offset(s * 0.42f, s * 0.42f), style = Stroke(width = s * 0.1f))
        drawLine(
            color, Offset(s * 0.66f, s * 0.66f), Offset(s * 0.9f, s * 0.9f),
            strokeWidth = s * 0.1f, cap = StrokeCap.Round
        )
    }
}

@Composable
fun SlidersGlyph(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.minDimension
        val sw = s * 0.08f
        val ys = listOf(0.25f, 0.5f, 0.75f)
        val xs = listOf(0.65f, 0.35f, 0.6f)
        for (i in 0..2) {
            drawLine(color, Offset(s * 0.1f, s * ys[i]), Offset(s * 0.9f, s * ys[i]), strokeWidth = sw, cap = StrokeCap.Round)
            drawCircle(color, radius = s * 0.09f, center = Offset(s * xs[i], s * ys[i]))
        }
    }
}

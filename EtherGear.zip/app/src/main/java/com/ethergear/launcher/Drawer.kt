package com.ethergear.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun initials(label: String): String =
    label.split(Regex("[^A-Za-z0-9]+")).filter { it.isNotEmpty() }.joinToString("") { it.take(1) }.lowercase()

@Composable
fun DrawerLayer(vm: LauncherViewModel) {
    val g = LocalGlass.current
    val bd = LocalBackdrop.current
    val ctx = LocalContext.current
    val prefs = vm.prefs
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<AppCategory?>(null) }

    BackHandler(enabled = query.isNotEmpty() || cat != null) {
        query = ""
        cat = null
    }

    val q = query.trim().lowercase()
    val visible = vm.visibleApps
    val shown = remember(visible, q, cat) {
        visible
            .filter {
                (cat == null || it.category == cat) &&
                    (q.isEmpty() || it.label.lowercase().contains(q) || initials(it.label).startsWith(q))
            }
            .sortedBy { if (q.isNotEmpty() && !it.label.lowercase().startsWith(q)) 1 else 0 }
    }
    val categories = remember(visible) {
        AppCategory.values().filter { c -> visible.any { it.category == c } }
    }

    Box(Modifier.fillMaxSize()) {
        if (bd != null) {
            Image(
                bd.blurred, null, Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.Low,
            )
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (g.dark) 0.5f else 0.3f)))

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .windowInsetsPadding(WindowInsets.navigationBars.union(WindowInsets.ime))
        ) {
            Row(
                Modifier
                    .padding(horizontal = 16.dp, vertical = 14.dp)
                    .fillMaxWidth()
                    .height(52.dp)
                    .glass(RoundedCornerShape(26.dp))
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SearchGlyph(g.subtext, Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) GText("Search apps", 16.sp, color = g.subtext)
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = g.text, fontSize = 16.sp, fontFamily = LocalFont.current),
                        cursorBrush = SolidColor(g.accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = {
                            if (shown.size == 1) {
                                launchApp(ctx, shown[0])
                                vm.drawerOpen = false
                            }
                        }),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Box(
                    Modifier.size(34.dp).springClick { vm.settingsOpen = true },
                    contentAlignment = Alignment.Center,
                ) { SlidersGlyph(g.text, Modifier.size(20.dp)) }
            }

            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                GChip("All", cat == null) { cat = null }
                categories.forEach { c -> GChip(c.title, cat == c) { cat = c } }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(prefs.columns),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 12.dp),
            ) {
                items(shown, key = { it.pkg }) { e ->
                    Box(Modifier.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                        AppCell(
                            e, prefs, true,
                            onClick = { launchApp(ctx, e); vm.drawerOpen = false },
                            onLongClick = { vm.menu = e },
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MenuRow(text: String, danger: Boolean = false, onClick: () -> Unit) {
    val g = LocalGlass.current
    Box(
        Modifier
            .fillMaxWidth()
            .springClick(0.97f, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 13.dp)
    ) {
        GText(text, 15.sp, FontWeight.Medium, color = if (danger) Color(0xFFFF6B7A) else g.text)
    }
}

@Composable
fun MenuOverlay(entry: AppEntry, vm: LauncherViewModel) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val prefs = vm.prefs
    val inHome = entry.pkg in prefs.homeApps
    val inDock = entry.pkg in prefs.dock

    fun act(block: () -> Unit): () -> Unit = {
        block()
        vm.menu = null
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .springClick(1f) { vm.menu = null },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .fillMaxWidth(0.85f)
                .widthIn(max = 340.dp)
                .glass(RoundedCornerShape(30.dp))
                .springClick(1f) { }
                .padding(14.dp),
        ) {
            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                val shape = IconShapes[prefs.shape.coerceIn(IconShapes.indices)].second
                Image(
                    entry.icon, entry.label,
                    Modifier.size(44.dp).clip(shape)
                )
                Spacer(Modifier.width(12.dp))
                GText(entry.label, 17.sp, FontWeight.SemiBold)
            }
            if (!inHome) MenuRow("Add to home", onClick = act { vm.addHome(entry.pkg) })
            else {
                MenuRow("Remove from home", onClick = act { vm.removeHome(entry.pkg) })
                MenuRow("Move earlier", onClick = { vm.moveHome(entry.pkg, -1) })
                MenuRow("Move later", onClick = { vm.moveHome(entry.pkg, 1) })
            }
            if (!inDock) MenuRow("Add to dock", onClick = act { vm.addDock(entry.pkg) })
            else MenuRow("Remove from dock", onClick = act { vm.removeDock(entry.pkg) })
            MenuRow("Hide app", onClick = act { vm.hide(entry.pkg) })
            MenuRow("App info", onClick = act { openAppInfo(ctx, entry) })
            MenuRow("Uninstall", danger = true, onClick = act { uninstallApp(ctx, entry) })
        }
    }
}


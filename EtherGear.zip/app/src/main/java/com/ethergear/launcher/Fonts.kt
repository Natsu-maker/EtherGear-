@file:OptIn(ExperimentalTextApi::class)

package com.ethergear.launcher

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** A font you can download from Google Fonts inside the app. */
class FontSpec(val name: String, val weight: Int) {
    val file: String get() = name.replace(" ", "") + ".ttf"
}

val FontCatalog = listOf(
    FontSpec("Sora", 500),
    FontSpec("Outfit", 500),
    FontSpec("Space Grotesk", 500),
    FontSpec("Poppins", 500),
    FontSpec("Orbitron", 500),
    FontSpec("Rajdhani", 500),
    FontSpec("Exo 2", 500),
    FontSpec("Chakra Petch", 500),
    FontSpec("Oxanium", 500),
    FontSpec("Audiowide", 400),
    FontSpec("Michroma", 400),
    FontSpec("Syncopate", 400),
    FontSpec("Russo One", 400),
    FontSpec("Bebas Neue", 400),
    FontSpec("Press Start 2P", 400),
)

/** Fonts you import live in the app's private storage and are loaded straight from there. */
object FontStore {
    private fun dir(ctx: Context): File = File(ctx.filesDir, "fonts").apply { mkdirs() }

    fun list(ctx: Context): List<String> =
        dir(ctx).listFiles()?.filter { it.isFile }?.map { it.name }?.sortedBy { it.lowercase() } ?: emptyList()

    fun delete(ctx: Context, name: String) {
        File(dir(ctx), name).delete()
    }

    private fun looksLikeFont(f: File): Boolean {
        if (!f.exists() || f.length() < 1000) return false
        val head = ByteArray(4)
        val n = f.inputStream().use { it.read(head) }
        if (n < 4) return false
        val tag = String(head, Charsets.ISO_8859_1)
        val isTtf = head[0].toInt() == 0 && head[1].toInt() == 1 && head[2].toInt() == 0 && head[3].toInt() == 0
        return isTtf || tag == "OTTO" || tag == "true" || tag == "ttcf"
    }

    fun family(ctx: Context, name: String): FontFamily {
        if (name.isEmpty()) return FontFamily.Default
        val f = File(dir(ctx), name)
        return try {
            if (!looksLikeFont(f)) return FontFamily.Default
            if (Typeface.createFromFile(f) == null) return FontFamily.Default
            FontFamily(
                Font(f, FontWeight.Normal),
                Font(f, FontWeight.Medium),
                Font(f, FontWeight.SemiBold),
                Font(f, FontWeight.Bold),
                Font(f, FontWeight.Light),
            )
        } catch (_: Throwable) {
            FontFamily.Default
        }
    }

    private val agents = listOf(
        "Mozilla/5.0 (Linux; U; Android 4.0.3; en-us) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",
        "Mozilla/5.0 (Linux; U; Android 2.2; en-us) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1",
    )

    private fun open(url: String, agent: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.setRequestProperty("User-Agent", agent)
        return c
    }

    /**
     * Downloads a font from Google Fonts. Asks Google's CSS endpoint for the .ttf link (old-browser
     * user agents get TTF instead of WOFF2), so no file names are hard-coded. Returns true on success.
     */
    suspend fun download(ctx: Context, spec: FontSpec): Boolean = withContext(Dispatchers.IO) {
        try {
            val cssUrl = "https://fonts.googleapis.com/css?family=" +
                URLEncoder.encode(spec.name, "UTF-8") + ":" + spec.weight
            var ttf: String? = null
            for (agent in agents) {
                val css = open(cssUrl, agent).inputStream.bufferedReader().use { it.readText() }
                ttf = Regex("url\\((https://[^)]+?\\.ttf)\\)").find(css)?.groupValues?.get(1)
                if (ttf != null) break
            }
            if (ttf == null) return@withContext false
            val out = File(dir(ctx), spec.file)
            open(ttf, agents[0]).inputStream.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            if (!looksLikeFont(out)) {
                out.delete()
                return@withContext false
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Copies a picked .ttf/.otf into private storage. Returns the stored file name, or null if invalid. */
    fun import(ctx: Context, uri: Uri): String? {
        var name: String? = null
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0)
            }
        } catch (_: Exception) {
        }
        val safe = (name ?: "font_${System.currentTimeMillis()}.ttf").replace(Regex("[^A-Za-z0-9._ -]"), "_")
        if (!(safe.endsWith(".ttf", true) || safe.endsWith(".otf", true))) return null
        val out = File(dir(ctx), safe)
        try {
            ctx.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                ?: return null
        } catch (_: Exception) {
            out.delete()
            return null
        }
        if (!looksLikeFont(out)) {
            out.delete()
            return null
        }
        return safe
    }
}

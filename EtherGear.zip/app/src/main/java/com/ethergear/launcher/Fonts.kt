package com.ethergear.launcher

import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import java.io.File

/** Fonts you import live in the app's private storage and are loaded straight from there. */
object FontStore {
    private fun dir(ctx: Context): File = File(ctx.filesDir, "fonts").apply { mkdirs() }

    fun list(ctx: Context): List<String> =
        dir(ctx).listFiles()?.filter { it.isFile }?.map { it.name }?.sortedBy { it.lowercase() } ?: emptyList()

    fun delete(ctx: Context, name: String) {
        File(dir(ctx), name).delete()
    }

    private fun looksLikeFont(f: File): Boolean {
        if (!f.exists() || f.length() < 1000) return false
        val head = ByteArray(4)
        val n = f.inputStream().use { it.read(head) }
        if (n < 4) return false
        val tag = String(head, Charsets.ISO_8859_1)
        val isTtf = head[0].toInt() == 0 && head[1].toInt() == 1 && head[2].toInt() == 0 && head[3].toInt() == 0
        return isTtf || tag == "OTTO" || tag == "true" || tag == "ttcf"
    }

    fun family(ctx: Context, name: String): FontFamily {
        if (name.isEmpty()) return FontFamily.Default
        val f = File(dir(ctx), name)
        return try {
            if (!looksLikeFont(f)) return FontFamily.Default
            if (Typeface.createFromFile(f) == null) return FontFamily.Default
            FontFamily(
                Font(f, FontWeight.Normal),
                Font(f, FontWeight.Medium),
                Font(f, FontWeight.SemiBold),
                Font(f, FontWeight.Bold),
                Font(f, FontWeight.Light),
            )
        } catch (_: Throwable) {
            FontFamily.Default
        }
    }

    /** Copies a picked .ttf/.otf into private storage. Returns the stored file name, or null if invalid. */
    fun import(ctx: Context, uri: Uri): String? {
        var name: String? = null
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0)
            }
        } catch (_: Exception) {
        }
        val safe = (name ?: "font_${System.currentTimeMillis()}.ttf").replace(Regex("[^A-Za-z0-9._ -]"), "_")
        if (!(safe.endsWith(".ttf", true) || safe.endsWith(".otf", true))) return null
        val out = File(dir(ctx), safe)
        try {
            ctx.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                ?: return null
        } catch (_: Exception) {
            out.delete()
            return null
        }
        if (!looksLikeFont(out)) {
            out.delete()
            return null
        }
        return safe
    }
}

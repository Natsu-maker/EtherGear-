package com.ethergear.launcher

import android.app.ActivityOptions
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.View
import android.widget.Toast

/** Launches an app. If the icon's on-screen bounds are known, the app zooms out of the icon. */
fun launchApp(ctx: Context, e: AppEntry, view: View? = null, bounds: IntArray? = null) {
    try {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(e.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val opts = if (view != null && bounds != null && bounds[2] > bounds[0] && bounds[3] > bounds[1]) {
            ActivityOptions.makeScaleUpAnimation(
                view, bounds[0], bounds[1], bounds[2] - bounds[0], bounds[3] - bounds[1]
            ).toBundle()
        } else null
        ctx.startActivity(i, opts)
    } catch (_: Exception) {
        Toast.makeText(ctx, "Can't open ${e.label}", Toast.LENGTH_SHORT).show()
    }
}

fun openAppInfo(ctx: Context, e: AppEntry) {
    try {
        ctx.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${e.pkg}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {
    }
}

fun uninstallApp(ctx: Context, e: AppEntry) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_DELETE, Uri.parse("package:${e.pkg}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (_: Exception) {
        Toast.makeText(ctx, "Can't uninstall ${e.label}", Toast.LENGTH_SHORT).show()
    }
}

fun expandShade(ctx: Context) {
    try {
        val sb = ctx.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
    } catch (_: Throwable) {
    }
}

fun openDefaultLauncherSettings(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }
}

/** True when EtherGear is the home app Android will open on the Home button. */
fun isDefaultLauncher(ctx: Context): Boolean {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
    val ri = ctx.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
    return ri?.activityInfo?.packageName == ctx.packageName
}

/**
 * Android 10+: the system "Set EtherGear as your default Home app?" dialog (one tap).
 * Older versions: the Home app settings screen.
 */
fun homeRoleIntent(ctx: Context): Intent {
    if (Build.VERSION.SDK_INT >= 29) {
        val rm = ctx.getSystemService(RoleManager::class.java)
        if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
            return rm.createRequestRoleIntent(RoleManager.ROLE_HOME)
        }
    }
    return Intent(Settings.ACTION_HOME_SETTINGS)
}

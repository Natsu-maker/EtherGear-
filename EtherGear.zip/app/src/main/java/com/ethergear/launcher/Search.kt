package com.ethergear.launcher

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.pow

/** Tiny calculator for the drawer search box: + - * / ^ % and parentheses. */
object Calc {
    fun eval(raw: String): String? {
        val s = raw.replace(" ", "").replace("×", "*").replace("÷", "/").replace(",", ".")
        if (s.length < 3 || !Regex("^[0-9+\\-*/^%().]+$").matches(s)) return null
        if (!s.drop(1).any { it in "+-*/^%" }) return null
        return try {
            val p = P(s)
            val v = p.expr()
            if (p.i != s.length || v.isNaN() || v.isInfinite()) null
            else BigDecimal(v).setScale(8, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
        } catch (_: Exception) {
            null
        }
    }

    private class P(val s: String) {
        var i = 0
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = factor()
            while (i < s.length && (s[i] == '*' || s[i] == '/' || s[i] == '%')) {
                val op = s[i++]
                val r = factor()
                v = when (op) {
                    '*' -> v * r
                    '/' -> v / r
                    else -> v % r
                }
            }
            return v
        }
        fun factor(): Double {
            val b = unary()
            if (i < s.length && s[i] == '^') {
                i++
                return b.pow(factor())
            }
            return b
        }
        fun unary(): Double {
            if (i < s.length && s[i] == '-') {
                i++
                return -unary()
            }
            if (i < s.length && s[i] == '+') {
                i++
                return unary()
            }
            return primary()
        }
        fun primary(): Double {
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                if (i >= s.length || s[i] != ')') throw IllegalStateException()
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalStateException()
            return s.substring(st, i).toDouble()
        }
    }
}

@Composable
fun ResultCard(expression: String, result: String, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    Column(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .springClick(0.97f) {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("result", result))
                Toast.makeText(ctx, "Copied $result", Toast.LENGTH_SHORT).show()
            }
            .glass(RoundedCornerShape(26.dp))
            .padding(horizontal = 20.dp, vertical = 14.dp),
    ) {
        GText(expression, 13.sp, color = g.subtext)
        GText("= $result", 30.sp, FontWeight.Light, clock = true, glow = g.accent.copy(alpha = 0.5f))
        GText("Tap to copy", 11.sp, color = g.subtext)
    }
}

@Composable
fun WebSearchRow(query: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    Row(modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.Center) {
        GChip("Search the web for \"${query.trim().take(28)}\"", false) {
            try {
                ctx.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query.trim())))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
        }
    }
}

@Composable
fun FrequentRow(vm: LauncherViewModel, apps: List<AppEntry>, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    Column(modifier.fillMaxWidth().padding(top = 4.dp, bottom = 2.dp)) {
        GText("FREQUENT", 12.sp, FontWeight.SemiBold, color = g.accent, letterSpacing = 1.4.sp, modifier = Modifier.padding(start = 12.dp, bottom = 4.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            apps.forEach { e ->
                AppCell(
                    e, vm.prefs, true,
                    onLongClick = { vm.menu = e },
                    modifier = Modifier.padding(horizontal = 6.dp),
                    afterLaunch = { vm.drawerOpen = false },
                )
            }
        }
    }
}

class Shortcut(val name: String, val action: String)

val SettingShortcuts = listOf(
    Shortcut("Wi-Fi", Settings.ACTION_WIFI_SETTINGS),
    Shortcut("Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS),
    Shortcut("Display and brightness", Settings.ACTION_DISPLAY_SETTINGS),
    Shortcut("Sound and volume", Settings.ACTION_SOUND_SETTINGS),
    Shortcut("Battery", Intent.ACTION_POWER_USAGE_SUMMARY),
    Shortcut("Storage", Settings.ACTION_INTERNAL_STORAGE_SETTINGS),
    Shortcut("Apps", Settings.ACTION_APPLICATION_SETTINGS),
    Shortcut("Location", Settings.ACTION_LOCATION_SOURCE_SETTINGS),
    Shortcut("Accessibility", Settings.ACTION_ACCESSIBILITY_SETTINGS),
    Shortcut("Airplane mode", Settings.ACTION_AIRPLANE_MODE_SETTINGS),
    Shortcut("Date and time", Settings.ACTION_DATE_SETTINGS),
    Shortcut("Language", Settings.ACTION_LOCALE_SETTINGS),
    Shortcut("Developer options", Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
)

@Composable
fun ShortcutRow(hits: List<Shortcut>, onOpen: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    Column(modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
        GText("SETTINGS", 12.sp, FontWeight.SemiBold, color = g.accent, letterSpacing = 1.4.sp, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            hits.forEach { h ->
                GChip(h.name, false) {
                    openSystemScreen(ctx, h.action)
                    onOpen()
                }
            }
        }
    }
}

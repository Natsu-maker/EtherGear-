package com.ethergear.launcher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs

/** Own gesture navigation, drawn as thin touch strips above everything (needs the accessibility toggle). */
class NavOverlay(private val service: AccessibilityService) {
    private val views = ArrayList<View>()

    fun show(pill: Boolean) {
        hide()
        val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = service.resources.displayMetrics
        val d = dm.density
        fun params(w: Int, h: Int, gravity: Int) = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply { this.gravity = gravity }

        try {
            val bottom = Strip(0, pill)
            wm.addView(bottom, params((dm.widthPixels * 0.45f).toInt(), (26 * d).toInt(), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
            views.add(bottom)
            val left = Strip(1, false)
            wm.addView(left, params((14 * d).toInt(), (dm.heightPixels * 0.5f).toInt(), Gravity.START or Gravity.CENTER_VERTICAL))
            views.add(left)
            val right = Strip(2, false)
            wm.addView(right, params((14 * d).toInt(), (dm.heightPixels * 0.5f).toInt(), Gravity.END or Gravity.CENTER_VERTICAL))
            views.add(right)
        } catch (_: Exception) {
        }
    }

    fun hide() {
        val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        for (v in views) {
            try {
                wm.removeView(v)
            } catch (_: Exception) {
            }
        }
        views.clear()
    }

    /** kind 0 = bottom (up = home, up and hold = recents), 1 = left edge, 2 = right edge (inward = back). */
    private inner class Strip(val kind: Int, val pill: Boolean) : View(service) {
        private var downX = 0f
        private var downY = 0f
        private var downT = 0L
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAAFFFFFF.toInt() }

        override fun onDraw(c: Canvas) {
            if (kind == 0 && pill) {
                val d = resources.displayMetrics.density
                val h = 4 * d
                val w = width * 0.5f
                val bottom = height - 6 * d
                c.drawRoundRect(RectF((width - w) / 2, bottom - h, (width + w) / 2, bottom), h / 2, h / 2, paint)
            }
        }

        private fun fire(action: Int) {
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            service.performGlobalAction(action)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val d = resources.displayMetrics.density
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    downT = e.eventTime
                }
                MotionEvent.ACTION_UP -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    val dt = e.eventTime - downT
                    when (kind) {
                        0 -> when {
                            -dy > 48 * d && -dy > abs(dx) ->
                                fire(if (dt > 420) AccessibilityService.GLOBAL_ACTION_RECENTS else AccessibilityService.GLOBAL_ACTION_HOME)
                            abs(dx) < 12 * d && abs(dy) < 12 * d && dt < 300 ->
                                fire(AccessibilityService.GLOBAL_ACTION_HOME)
                        }
                        1 -> if (dx > 56 * d && dx > abs(dy)) fire(AccessibilityService.GLOBAL_ACTION_BACK)
                        2 -> if (-dx > 56 * d && -dx > abs(dy)) fire(AccessibilityService.GLOBAL_ACTION_BACK)
                    }
                }
            }
            return true
        }
    }
}

const val SECURE_PERMISSION = "android.permission.WRITE_SECURE_SETTINGS"
const val ADB_GRANT = "adb shell pm grant com.ethergear.launcher android.permission.WRITE_SECURE_SETTINGS"

fun canHideNavBar(ctx: Context): Boolean =
    ctx.checkSelfPermission(SECURE_PERMISSION) == PackageManager.PERMISSION_GRANTED

/** Hides or restores the system navigation bar (Android 10 and older only). */
fun setNavBarHidden(ctx: Context, hide: Boolean): Boolean = try {
    Settings.Global.putString(ctx.contentResolver, "policy_control", if (hide) "immersive.navigation=*" else null)
    true
} catch (_: Exception) {
    false
}

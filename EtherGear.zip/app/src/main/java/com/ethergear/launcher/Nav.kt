package com.ethergear.launcher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs

/** Own gesture navigation, drawn as thin touch strips above everything (needs the accessibility toggle). */
class NavOverlay(private val service: AccessibilityService) {
    private val views = ArrayList<View>()
    private var bottom: Strip? = null
    private var bottomLp: WindowManager.LayoutParams? = null
    private var wmRef: WindowManager? = null

    fun show(pill: Boolean) {
        hide()
        val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wmRef = wm
        val dm = service.resources.displayMetrics
        val d = dm.density
        fun params(w: Int, h: Int, gravity: Int) = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply { this.gravity = gravity }

        try {
            val b = Strip(0, pill)
            val blp = params((dm.widthPixels * 0.45f).toInt(), (26 * d).toInt(), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            wm.addView(b, blp)
            views.add(b)
            bottom = b
            bottomLp = blp
            val left = Strip(1, false)
            wm.addView(left, params((14 * d).toInt(), (dm.heightPixels * 0.5f).toInt(), Gravity.START or Gravity.CENTER_VERTICAL))
            views.add(left)
            val right = Strip(2, false)
            wm.addView(right, params((14 * d).toInt(), (dm.heightPixels * 0.5f).toInt(), Gravity.END or Gravity.CENTER_VERTICAL))
            views.add(right)
        } catch (_: Exception) {
        }
    }

    /** Covers the system's 3 buttons with a black gesture bar (used while another app is on screen). */
    fun cover(on: Boolean) {
        val b = bottom ?: return
        val lp = bottomLp ?: return
        val dm = service.resources.displayMetrics
        if (on) {
            lp.width = dm.widthPixels
            lp.height = navHeight()
        } else {
            lp.width = (dm.widthPixels * 0.45f).toInt()
            lp.height = (26 * dm.density).toInt()
        }
        b.covering = on
        try {
            wmRef?.updateViewLayout(b, lp)
        } catch (_: Exception) {
        }
        b.invalidate()
    }

    private fun navHeight(): Int {
        val r = service.resources
        val id = r.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) r.getDimensionPixelSize(id) else (48 * r.displayMetrics.density).toInt()
    }

    fun hide() {
        bottom = null
        bottomLp = null
        val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        for (v in views) {
            try {
                wm.removeView(v)
            } catch (_: Exception) {
            }
        }
        views.clear()
    }

    /** kind 0 = bottom (up = home, up and hold = recents), 1 = left edge, 2 = right edge (inward = back). */
    private inner class Strip(val kind: Int, val pill: Boolean) : View(service) {
        private var downX = 0f
        private var downY = 0f
        private var downT = 0L
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAAFFFFFF.toInt() }
        var covering = false

        override fun onDraw(c: Canvas) {
            if (kind != 0) return
            if (covering) c.drawColor(android.graphics.Color.BLACK)
            if (pill || covering) {
                val d = resources.displayMetrics.density
                val h = 4 * d
                val w = width * (if (covering) 0.28f else 0.5f)
                val yb = if (covering) height / 2f + h / 2f else height - 6 * d
                c.drawRoundRect(RectF((width - w) / 2, yb - h, (width + w) / 2, yb), h / 2, h / 2, paint)
            }
        }

        private fun fire(action: Int) {
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            service.performGlobalAction(action)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            val d = resources.displayMetrics.density
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    downT = e.eventTime
                }
                MotionEvent.ACTION_UP -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    val dt = e.eventTime - downT
                    when (kind) {
                        0 -> when {
                            -dy > 48 * d && -dy > abs(dx) ->
                                fire(if (dt > 420) AccessibilityService.GLOBAL_ACTION_RECENTS else AccessibilityService.GLOBAL_ACTION_HOME)
                            abs(dx) < 12 * d && abs(dy) < 12 * d && dt < 300 ->
                                fire(AccessibilityService.GLOBAL_ACTION_HOME)
                        }
                        1 -> if (dx > 56 * d && dx > abs(dy)) fire(AccessibilityService.GLOBAL_ACTION_BACK)
                        2 -> if (-dx > 56 * d && -dx > abs(dy)) fire(AccessibilityService.GLOBAL_ACTION_BACK)
                    }
                }
            }
            return true
        }
    }
}

const val SECURE_PERMISSION = "android.permission.WRITE_SECURE_SETTINGS"
const val ADB_GRANT = "adb shell pm grant com.ethergear.launcher android.permission.WRITE_SECURE_SETTINGS"

fun canHideNavBar(ctx: Context): Boolean =
    ctx.checkSelfPermission(SECURE_PERMISSION) == PackageManager.PERMISSION_GRANTED

/** Hides or restores the system navigation bar (Android 10 and older only). */
fun setNavBarHidden(ctx: Context, hide: Boolean): Boolean = try {
    Settings.Global.putString(ctx.contentResolver, "policy_control", if (hide) "immersive.navigation=*" else null)
    true
} catch (_: Exception) {
    false
}

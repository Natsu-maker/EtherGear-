package com.ethergear.launcher

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class Folder(val id: String, val name: String, val apps: List<String>)

/**
 * All launcher settings. Every property is Compose state, so the UI updates live.
 * homeApps holds tokens: a package name, or "f:<folderId>" for a folder.
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("ethergear", Context.MODE_PRIVATE)

    var dark by mutableStateOf(sp.getBoolean("dark", true))
    var tint by mutableStateOf(sp.getFloat("tint", 0.30f))
    var accent by mutableIntStateOf(sp.getInt("accent", 0))
    var shape by mutableIntStateOf(sp.getInt("shape", 1))
    var columns by mutableIntStateOf(sp.getInt("columns", 4))
    var showLabels by mutableStateOf(sp.getBoolean("labels", true))
    var iconSize by mutableStateOf(sp.getFloat("iconSize", 56f))
    var fontMain by mutableStateOf(sp.getString("fontMain", "") ?: "")
    var fontClock by mutableStateOf(sp.getString("fontClock", "") ?: "")
    var homeApps by mutableStateOf(readList("home"))
    var dock by mutableStateOf(readList("dock"))
    var hidden by mutableStateOf(readList("hidden").toSet())
    var locked by mutableStateOf(readList("locked").toSet())
    var games by mutableStateOf(readList("games").toSet())
    var folders by mutableStateOf(readFolders())
    var seeded by mutableStateOf(sp.getBoolean("seeded", false))
    var skipDefaultPrompt by mutableStateOf(sp.getBoolean("skipDefaultPrompt", false))
    var badgesOn by mutableStateOf(sp.getBoolean("badgesOn", true))
    var doubleTapLock by mutableStateOf(sp.getBoolean("doubleTapLock", false))
    var widgetsPage by mutableStateOf(sp.getBoolean("widgetsPage", true))
    var wallpaperVersion by mutableIntStateOf(0)

    private fun readList(key: String): List<String> =
        (sp.getString(key, "") ?: "").split("\n").filter { it.isNotEmpty() }

    private fun writeList(key: String, v: Collection<String>) {
        sp.edit().putString(key, v.joinToString("\n")).apply()
    }

    private fun readFolders(): Map<String, Folder> {
        val out = LinkedHashMap<String, Folder>()
        for (line in (sp.getString("folders", "") ?: "").split("\n")) {
            if (line.isBlank()) continue
            val p = line.split("\t")
            if (p.size < 3) continue
            out[p[0]] = Folder(p[0], p[1], p[2].split(",").filter { it.isNotEmpty() })
        }
        return out
    }

    fun updateDark(v: Boolean) { dark = v; sp.edit().putBoolean("dark", v).apply() }
    fun updateTint(v: Float) { tint = v; sp.edit().putFloat("tint", v).apply() }
    fun updateAccent(v: Int) { accent = v; sp.edit().putInt("accent", v).apply() }
    fun updateShape(v: Int) { shape = v; sp.edit().putInt("shape", v).apply() }
    fun updateColumns(v: Int) { columns = v; sp.edit().putInt("columns", v).apply() }
    fun updateLabels(v: Boolean) { showLabels = v; sp.edit().putBoolean("labels", v).apply() }
    fun updateIconSize(v: Float) { iconSize = v; sp.edit().putFloat("iconSize", v).apply() }
    fun updateFontMain(v: String) { fontMain = v; sp.edit().putString("fontMain", v).apply() }
    fun updateFontClock(v: String) { fontClock = v; sp.edit().putString("fontClock", v).apply() }
    fun updateHome(v: List<String>) { homeApps = v; writeList("home", v) }
    fun updateDock(v: List<String>) { dock = v; writeList("dock", v) }
    fun updateHidden(v: Set<String>) { hidden = v; writeList("hidden", v) }
    fun updateLocked(v: Set<String>) { locked = v; writeList("locked", v) }
    fun updateGames(v: Set<String>) { games = v; writeList("games", v) }
    fun updateFolders(v: Map<String, Folder>) {
        folders = v
        val s = v.values.joinToString("\n") {
            val n = it.name.replace('\t', ' ').replace('\n', ' ')
            "${it.id}\t$n\t${it.apps.joinToString(",")}"
        }
        sp.edit().putString("folders", s).apply()
    }
    fun updateSkipDefaultPrompt(v: Boolean) { skipDefaultPrompt = v; sp.edit().putBoolean("skipDefaultPrompt", v).apply() }
    fun updateBadgesOn(v: Boolean) { badgesOn = v; sp.edit().putBoolean("badgesOn", v).apply() }
    fun updateDoubleTapLock(v: Boolean) { doubleTapLock = v; sp.edit().putBoolean("doubleTapLock", v).apply() }
    fun updateWidgetsPage(v: Boolean) { widgetsPage = v; sp.edit().putBoolean("widgetsPage", v).apply() }
    fun markSeeded() { seeded = true; sp.edit().putBoolean("seeded", true).apply() }
    fun unseed() { seeded = false; sp.edit().putBoolean("seeded", false).apply() }
    fun bumpWallpaper() { wallpaperVersion++ }
}

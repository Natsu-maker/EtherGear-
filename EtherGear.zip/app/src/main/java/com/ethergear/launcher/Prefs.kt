package com.ethergear.launcher

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject

class Folder(val id: String, val name: String, val apps: List<String>)

class ThemePreset(val name: String, val dark: Boolean, val tint: Float, val accent: Int, val shape: Int, val dim: Float)

val ThemePresets = listOf(
    ThemePreset("Aurora", true, 0.30f, 0, 1, 0.10f),
    ThemePreset("Amethyst", true, 0.35f, 1, 2, 0.15f),
    ThemePreset("Sakura", false, 0.25f, 2, 0, 0.00f),
    ThemePreset("Matrix", true, 0.45f, 3, 4, 0.25f),
    ThemePreset("Sunset", true, 0.28f, 4, 3, 0.12f),
    ThemePreset("Crimson", true, 0.40f, 5, 1, 0.20f),
    ThemePreset("Wallpaper", true, 0.30f, -1, 1, 0.10f),
)

/**
 * All launcher settings. Every property is Compose state, so the UI updates live.
 * homeApps holds tokens: a package name, or "f:<folderId>" for a folder.
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("ethergear", Context.MODE_PRIVATE)

    var dark by mutableStateOf(sp.getBoolean("dark", true))
    var tint by mutableStateOf(sp.getFloat("tint", 0.30f))
    var accent by mutableIntStateOf(sp.getInt("accent", 0))
    var shape by mutableIntStateOf(sp.getInt("shape", 1))
    var columns by mutableIntStateOf(sp.getInt("columns", 4))
    var showLabels by mutableStateOf(sp.getBoolean("labels", true))
    var iconSize by mutableStateOf(sp.getFloat("iconSize", 56f))
    var fontMain by mutableStateOf(sp.getString("fontMain", "") ?: "")
    var fontClock by mutableStateOf(sp.getString("fontClock", "") ?: "")
    var homeApps by mutableStateOf(readList("home"))
    var dock by mutableStateOf(readList("dock"))
    var hidden by mutableStateOf(readList("hidden").toSet())
    var locked by mutableStateOf(readList("locked").toSet())
    var games by mutableStateOf(readList("games").toSet())
    var folders by mutableStateOf(readFolders())
    var seeded by mutableStateOf(sp.getBoolean("seeded", false))
    var skipDefaultPrompt by mutableStateOf(sp.getBoolean("skipDefaultPrompt", false))
    var badgesOn by mutableStateOf(sp.getBoolean("badgesOn", true))
    var doubleTapLock by mutableStateOf(sp.getBoolean("doubleTapLock", false))
    var widgetsPage by mutableStateOf(sp.getBoolean("widgetsPage", true))
    var focusApps by mutableStateOf(readList("focusApps").toSet())
    var focusOn by mutableStateOf(sp.getBoolean("focusOn", false))
    var swipeDown by mutableIntStateOf(sp.getInt("swipeDown", 0))
    var launchCounts by mutableStateOf(readCounts())
    var perf by mutableIntStateOf(sp.getInt("perf", 0))
    var drawerSort by mutableIntStateOf(sp.getInt("drawerSort", 0))
    var clockStyle by mutableIntStateOf(sp.getInt("clockStyle", 0))
    var autoDark by mutableStateOf(sp.getBoolean("autoDark", false))
    var dim by mutableStateOf(sp.getFloat("dim", 0f))
    var haptics by mutableStateOf(sp.getBoolean("haptics", true))
    var layoutLock by mutableStateOf(sp.getBoolean("layoutLock", false))
    var note by mutableStateOf(sp.getString("note", "") ?: "")
    var navGestures by mutableStateOf(sp.getBoolean("navGestures", false))
    var navPill by mutableStateOf(sp.getBoolean("navPill", true))
    var navHidden by mutableStateOf(sp.getBoolean("navHidden", false))
    var navCover by mutableStateOf(sp.getBoolean("navCover", true))
    var customLabels by mutableStateOf(readLabels())

    /** Apps hidden right now: your hidden list, plus the focus list while Focus is on. */
    val effHidden: Set<String> get() = if (focusOn) hidden + focusApps else hidden
    var wallpaperVersion by mutableIntStateOf(0)

    private fun readList(key: String): List<String> =
        (sp.getString(key, "") ?: "").split("\n").filter { it.isNotEmpty() }

    private fun writeList(key: String, v: Collection<String>) {
        sp.edit().putString(key, v.joinToString("\n")).apply()
    }

    private fun readFolders(): Map<String, Folder> {
        val out = LinkedHashMap<String, Folder>()
        for (line in (sp.getString("folders", "") ?: "").split("\n")) {
            if (line.isBlank()) continue
            val p = line.split("\t")
            if (p.size < 3) continue
            out[p[0]] = Folder(p[0], p[1], p[2].split(",").filter { it.isNotEmpty() })
        }
        return out
    }

    fun updateDark(v: Boolean) { dark = v; sp.edit().putBoolean("dark", v).apply() }
    fun updateTint(v: Float) { tint = v; sp.edit().putFloat("tint", v).apply() }
    fun updateAccent(v: Int) { accent = v; sp.edit().putInt("accent", v).apply() }
    fun updateShape(v: Int) { shape = v; sp.edit().putInt("shape", v).apply() }
    fun updateColumns(v: Int) { columns = v; sp.edit().putInt("columns", v).apply() }
    fun updateLabels(v: Boolean) { showLabels = v; sp.edit().putBoolean("labels", v).apply() }
    fun updateIconSize(v: Float) { iconSize = v; sp.edit().putFloat("iconSize", v).apply() }
    fun updateFontMain(v: String) { fontMain = v; sp.edit().putString("fontMain", v).apply() }
    fun updateFontClock(v: String) { fontClock = v; sp.edit().putString("fontClock", v).apply() }
    fun updateHome(v: List<String>) { homeApps = v; writeList("home", v) }
    fun updateDock(v: List<String>) { dock = v; writeList("dock", v) }
    fun updateHidden(v: Set<String>) { hidden = v; writeList("hidden", v) }
    fun updateLocked(v: Set<String>) { locked = v; writeList("locked", v) }
    fun updateGames(v: Set<String>) { games = v; writeList("games", v) }
    fun updateFolders(v: Map<String, Folder>) {
        folders = v
        val s = v.values.joinToString("\n") {
            val n = it.name.replace('\t', ' ').replace('\n', ' ')
            "${it.id}\t$n\t${it.apps.joinToString(",")}"
        }
        sp.edit().putString("folders", s).apply()
    }
    fun updateSkipDefaultPrompt(v: Boolean) { skipDefaultPrompt = v; sp.edit().putBoolean("skipDefaultPrompt", v).apply() }
    fun updateBadgesOn(v: Boolean) { badgesOn = v; sp.edit().putBoolean("badgesOn", v).apply() }
    fun updateDoubleTapLock(v: Boolean) { doubleTapLock = v; sp.edit().putBoolean("doubleTapLock", v).apply() }
    fun updateWidgetsPage(v: Boolean) { widgetsPage = v; sp.edit().putBoolean("widgetsPage", v).apply() }
    fun updateFocusApps(v: Set<String>) { focusApps = v; writeList("focusApps", v) }
    fun updateFocusOn(v: Boolean) { focusOn = v; sp.edit().putBoolean("focusOn", v).apply() }
    fun updatePerf(v: Int) { perf = v; sp.edit().putInt("perf", v).apply() }
    fun updateDrawerSort(v: Int) { drawerSort = v; sp.edit().putInt("drawerSort", v).apply() }
    fun updateClockStyle(v: Int) { clockStyle = v; sp.edit().putInt("clockStyle", v).apply() }
    fun updateAutoDark(v: Boolean) { autoDark = v; sp.edit().putBoolean("autoDark", v).apply() }
    fun updateDim(v: Float) { dim = v; sp.edit().putFloat("dim", v).apply() }
    fun updateHaptics(v: Boolean) { haptics = v; sp.edit().putBoolean("haptics", v).apply() }
    fun updateLayoutLock(v: Boolean) { layoutLock = v; sp.edit().putBoolean("layoutLock", v).apply() }
    fun updateNote(v: String) { note = v; sp.edit().putString("note", v).apply() }
    fun updateNavGestures(v: Boolean) {
        navGestures = v
        sp.edit().putBoolean("navGestures", v).apply()
        LockService.instance?.refreshNav()
    }
    fun updateNavPill(v: Boolean) {
        navPill = v
        sp.edit().putBoolean("navPill", v).apply()
        LockService.instance?.refreshNav()
    }
    fun updateNavCover(v: Boolean) {
        navCover = v
        sp.edit().putBoolean("navCover", v).apply()
        LockService.instance?.refreshNav()
    }
    fun updateNavHidden(v: Boolean) { navHidden = v; sp.edit().putBoolean("navHidden", v).apply() }

    fun updateLabel(pkg: String, label: String?) {
        val m = customLabels.toMutableMap()
        val clean = label?.trim()?.take(24)?.replace('\t', ' ')?.replace('\n', ' ')
        if (clean.isNullOrBlank()) m.remove(pkg) else m[pkg] = clean
        customLabels = m
        sp.edit().putString("labels", m.entries.joinToString("\n") { "${it.key}\t${it.value}" }).apply()
    }

    private fun readLabels(): Map<String, String> {
        val out = HashMap<String, String>()
        for (line in (sp.getString("labels", "") ?: "").split("\n")) {
            val p = line.split("\t", limit = 2)
            if (p.size == 2 && p[0].isNotEmpty() && p[1].isNotEmpty()) out[p[0]] = p[1]
        }
        return out
    }

    fun applyPreset(t: ThemePreset) {
        updateDark(t.dark)
        updateAutoDark(false)
        updateTint(t.tint)
        updateAccent(t.accent)
        updateShape(t.shape)
        updateDim(t.dim)
    }
    fun updateSwipeDown(v: Int) { swipeDown = v; sp.edit().putInt("swipeDown", v).apply() }

    fun recordLaunch(pkg: String) {
        val m = launchCounts.toMutableMap()
        m[pkg] = (m[pkg] ?: 0) + 1
        launchCounts = m
        sp.edit().putString("counts", m.entries.joinToString("\n") { "${it.key}\t${it.value}" }).apply()
    }

    private fun readCounts(): Map<String, Int> {
        val out = HashMap<String, Int>()
        for (line in (sp.getString("counts", "") ?: "").split("\n")) {
            val p = line.split("\t")
            if (p.size == 2) p[1].toIntOrNull()?.let { out[p[0]] = it }
        }
        return out
    }

    /** Everything (layout, folders, locks, settings) as one JSON string. */
    fun exportJson(): String {
        val root = JSONObject()
        val o = JSONObject()
        for ((k, v) in sp.all) {
            val e = JSONObject()
            when (v) {
                is String -> { e.put("t", "s"); e.put("v", v) }
                is Boolean -> { e.put("t", "b"); e.put("v", v) }
                is Int -> { e.put("t", "i"); e.put("v", v) }
                is Float -> { e.put("t", "f"); e.put("v", v.toDouble()) }
                is Long -> { e.put("t", "l"); e.put("v", v) }
                else -> continue
            }
            o.put(k, e)
        }
        root.put("app", "EtherGear")
        root.put("prefs", o)
        return root.toString()
    }

    fun importJson(text: String): Boolean {
        return try {
            val root = JSONObject(text)
            if (root.optString("app") != "EtherGear") return false
            val o = root.getJSONObject("prefs")
            val ed = sp.edit().clear()
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val e = o.getJSONObject(k)
                when (e.getString("t")) {
                    "s" -> ed.putString(k, e.getString("v"))
                    "b" -> ed.putBoolean(k, e.getBoolean("v"))
                    "i" -> ed.putInt(k, e.getInt("v"))
                    "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                    "l" -> ed.putLong(k, e.getLong("v"))
                }
            }
            ed.apply()
            reload()
            true
        } catch (_: Exception) {
            false
        }
    }

    fun reload() {
        dark = sp.getBoolean("dark", true)
        tint = sp.getFloat("tint", 0.30f)
        accent = sp.getInt("accent", 0)
        shape = sp.getInt("shape", 1)
        columns = sp.getInt("columns", 4)
        showLabels = sp.getBoolean("labels", true)
        iconSize = sp.getFloat("iconSize", 56f)
        fontMain = sp.getString("fontMain", "") ?: ""
        fontClock = sp.getString("fontClock", "") ?: ""
        homeApps = readList("home")
        dock = readList("dock")
        hidden = readList("hidden").toSet()
        locked = readList("locked").toSet()
        games = readList("games").toSet()
        folders = readFolders()
        seeded = sp.getBoolean("seeded", false)
        skipDefaultPrompt = sp.getBoolean("skipDefaultPrompt", false)
        badgesOn = sp.getBoolean("badgesOn", true)
        doubleTapLock = sp.getBoolean("doubleTapLock", false)
        widgetsPage = sp.getBoolean("widgetsPage", true)
        focusApps = readList("focusApps").toSet()
        focusOn = sp.getBoolean("focusOn", false)
        swipeDown = sp.getInt("swipeDown", 0)
        launchCounts = readCounts()
        perf = sp.getInt("perf", 0)
        drawerSort = sp.getInt("drawerSort", 0)
        clockStyle = sp.getInt("clockStyle", 0)
        autoDark = sp.getBoolean("autoDark", false)
        dim = sp.getFloat("dim", 0f)
        haptics = sp.getBoolean("haptics", true)
        layoutLock = sp.getBoolean("layoutLock", false)
        note = sp.getString("note", "") ?: ""
        navGestures = sp.getBoolean("navGestures", false)
        navPill = sp.getBoolean("navPill", true)
        navHidden = sp.getBoolean("navHidden", false)
        navCover = sp.getBoolean("navCover", true)
        customLabels = readLabels()
    }

    fun markSeeded() { seeded = true; sp.edit().putBoolean("seeded", true).apply() }
    fun unseed() { seeded = false; sp.edit().putBoolean("seeded", false).apply() }
    fun bumpWallpaper() { wallpaperVersion++ }
}

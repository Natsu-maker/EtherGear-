package com.ethergear.launcher

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

/** Opens the system "make this your Home app" dialog. */
val LocalSetDefault = staticCompositionLocalOf<() -> Unit> { {} }

/** Asks for your screen lock (PIN, pattern or fingerprint), then runs the action. */
val LocalAuth = staticCompositionLocalOf<(String, () -> Unit) -> Unit> { { _, run -> run() } }

@Composable
fun EtherGearApp(vm: LauncherViewModel) {
    val prefs = vm.prefs
    val ctx = LocalContext.current

    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        vm.checkDefault()
    }
    val setDefault: () -> Unit = remember {
        {
            try {
                roleLauncher.launch(homeRoleIntent(ctx))
            } catch (_: Exception) {
                openDefaultLauncherSettings(ctx)
            }
        }
    }

    val pendingAuth = remember { arrayOfNulls<() -> Unit>(1) }
    val authLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val run = pendingAuth[0]
        pendingAuth[0] = null
        if (res.resultCode == Activity.RESULT_OK) run?.invoke()
    }
    val auth: (String, () -> Unit) -> Unit = remember {
        { reason, run ->
            val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            val intent = if (km.isDeviceSecure) km.createConfirmDeviceCredentialIntent("EtherGear", reason) else null
            if (intent == null) {
                Toast.makeText(ctx, "Set a screen lock in system settings to protect locked apps", Toast.LENGTH_LONG).show()
                run()
            } else {
                pendingAuth[0] = run
                try {
                    authLauncher.launch(intent)
                } catch (_: Exception) {
                    pendingAuth[0] = null
                    Toast.makeText(ctx, "Couldn't open the lock screen", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize().background(Color(0xFF05070D))) {
        val density = LocalDensity.current
        val wPx = with(density) { maxWidth.roundToPx() }
        val hPx = with(density) { maxHeight.roundToPx() }

        var backdrop by remember { mutableStateOf<Backdrop?>(null) }
        LaunchedEffect(wPx, hPx, prefs.wallpaperVersion) {
            backdrop = withContext(Dispatchers.Default) { WallpaperEngine.build(ctx, wPx, hPx) }
        }

        val glass = GlassTheme(prefs.dark, prefs.tint, Accents[prefs.accent.coerceIn(Accents.indices)])
        val mainFont = remember(prefs.fontMain, vm.fontTick) { FontStore.family(ctx, prefs.fontMain) }
        val clockFont = remember(prefs.fontClock, vm.fontTick) { FontStore.family(ctx, prefs.fontClock) }

        CompositionLocalProvider(
            LocalGlass provides glass,
            LocalBackdrop provides backdrop,
            LocalFont provides mainFont,
            LocalClockFont provides clockFont,
            LocalSetDefault provides setDefault,
            LocalAuth provides auth,
        ) {
            AppContent(vm)
        }
    }
}

@Composable
private fun AppContent(vm: LauncherViewModel) {
    val bd = LocalBackdrop.current

    BackHandler(
        enabled = vm.menu != null || vm.bloatOpen || vm.settingsOpen || vm.drawerOpen || vm.editMode ||
            vm.openFolder != null
    ) {
        when {
            vm.menu != null -> vm.menu = null
            vm.bloatOpen -> vm.bloatOpen = false
            vm.settingsOpen -> vm.settingsOpen = false
            vm.openFolder != null -> vm.openFolder = null
            vm.drawerOpen -> vm.drawerOpen = false
            vm.editMode -> vm.editMode = false
        }
    }

    // ---- Drawer progress: follows the finger while dragging, springs otherwise. ----
    val prog = remember { Animatable(0f) }
    LaunchedEffect(vm.dragging, vm.dragP) {
        if (vm.dragging) prog.snapTo(vm.dragP)
    }
    LaunchedEffect(vm.drawerOpen, vm.dragging) {
        if (!vm.dragging) {
            prog.animateTo(if (vm.drawerOpen) 1f else 0f, spring(dampingRatio = 0.86f, stiffness = 320f))
        }
    }
    val settingsP = animateFloatAsState(
        if (vm.settingsOpen) 1f else 0f,
        spring(dampingRatio = 0.9f, stiffness = 300f),
        label = "settingsP"
    )
    val drawerVisible by remember { derivedStateOf { prog.value > 0.002f } }

    // ---- Wallpaper: parallax with the page, gentle zoom while a layer is open. ----
    Box(
        Modifier.fillMaxSize().graphicsLayer {
            val p = max(prog.value, settingsP.value)
            val s = 1.1f + 0.05f * p
            scaleX = s
            scaleY = s
            translationX = (0.5f - vm.pageFrac) * size.width * 0.08f
        }
    ) {
        Crossfade(bd, animationSpec = tween(700), label = "wallpaper") { b ->
            if (b != null) {
                Image(b.sharp, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
            }
        }
    }
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                listOf(Color.Black.copy(alpha = 0.35f), Color.Transparent, Color.Black.copy(alpha = 0.5f))
            )
        )
    )

    // ---- Home recedes as a layer opens. ----
    Box(
        Modifier.fillMaxSize().graphicsLayer {
            val p = max(prog.value, settingsP.value)
            val s = 1f - 0.06f * p
            scaleX = s
            scaleY = s
            alpha = 1f - 0.7f * p
        }
    ) { HomeLayer(vm) }

    // ---- Drawer (only composed while visible, so search resets every time it opens). ----
    if (drawerVisible) {
        Box(
            Modifier
                .fillMaxSize()
                .offset { IntOffset(0, ((1f - prog.value) * 120.dp.toPx()).roundToInt()) }
                .graphicsLayer { alpha = prog.value.coerceIn(0f, 1f) }
        ) { DrawerLayer(vm) }
    }

    AnimatedVisibility(
        visible = vm.settingsOpen,
        enter = fadeIn(tween(260)) + slideInVertically(spring(dampingRatio = 0.85f, stiffness = 300f)) { it / 10 },
        exit = fadeOut(tween(200)) + slideOutVertically(tween(220)) { it / 10 },
    ) { SettingsLayer(vm) }

    AnimatedVisibility(
        visible = vm.bloatOpen,
        enter = fadeIn(tween(240)) + slideInVertically(spring(dampingRatio = 0.85f, stiffness = 300f)) { it / 10 },
        exit = fadeOut(tween(180)) + slideOutVertically(tween(200)) { it / 10 },
    ) { BloatLayer(vm) }

    // ---- Open folder: scrim fades, panel springs in. ----
    val folderHolder = remember { arrayOfNulls<String>(1) }
    val folderId = vm.openFolder
    if (folderId != null) folderHolder[0] = folderId
    val folderVisible = folderId != null && vm.prefs.folders.containsKey(folderId)
    AnimatedVisibility(
        visible = folderVisible,
        enter = fadeIn(tween(180)),
        exit = fadeOut(tween(160)),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .pointerInput(Unit) { detectTapGestures { vm.openFolder = null } }
        )
    }
    AnimatedVisibility(
        visible = folderVisible,
        enter = fadeIn(tween(160)) + scaleIn(initialScale = 0.8f, animationSpec = spring(dampingRatio = 0.7f, stiffness = 380f)),
        exit = fadeOut(tween(130)) + scaleOut(targetScale = 0.9f, animationSpec = tween(130)),
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            folderHolder[0]?.let { FolderPanel(vm, it) }
        }
    }

    // ---- Long-press menu: scrim fades, panel springs in. ----
    val menuHolder = remember { arrayOfNulls<AppEntry>(1) }
    vm.menu?.let { menuHolder[0] = it }
    AnimatedVisibility(
        visible = vm.menu != null,
        enter = fadeIn(tween(180)),
        exit = fadeOut(tween(160)),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .pointerInput(Unit) { detectTapGestures { vm.menu = null } }
        )
    }
    AnimatedVisibility(
        visible = vm.menu != null,
        enter = fadeIn(tween(160)) + scaleIn(initialScale = 0.86f, animationSpec = spring(dampingRatio = 0.68f, stiffness = 420f)),
        exit = fadeOut(tween(130)) + scaleOut(targetScale = 0.94f, animationSpec = tween(130)),
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            menuHolder[0]?.let { MenuPanel(it, vm) }
        }
    }

    // ---- "Make EtherGear your home app" popup. ----
    LaunchedEffect(Unit) {
        delay(1800)
        vm.promptReady = true
    }
    val showPrompt = !vm.isDefault && !vm.prefs.skipDefaultPrompt && !vm.promptDismissed &&
        vm.promptReady && vm.apps.isNotEmpty() && !vm.drawerOpen && !vm.settingsOpen && vm.menu == null
    AnimatedVisibility(
        visible = showPrompt,
        enter = fadeIn(tween(320)) + scaleIn(initialScale = 0.9f, animationSpec = spring(dampingRatio = 0.7f, stiffness = 300f)),
        exit = fadeOut(tween(220)) + scaleOut(targetScale = 0.95f, animationSpec = tween(220)),
    ) { DefaultLauncherDialog(vm) }
}

@Composable
private fun SpinningGear(modifier: Modifier, accent: Color) {
    val t = rememberInfiniteTransition(label = "gear")
    val rot = t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(12000, easing = LinearEasing)),
        label = "rot"
    )
    Canvas(modifier) {
        val c = center
        val m = size.minDimension
        val r = m * 0.30f
        val tooth = m * 0.12f
        val tw = m * 0.13f
        rotate(rot.value, c) {
            for (i in 0 until 8) {
                rotate(i * 45f, c) {
                    drawRoundRect(
                        accent,
                        topLeft = Offset(c.x - tw / 2, c.y - r - tooth),
                        size = Size(tw, tooth + r * 0.3f),
                        cornerRadius = CornerRadius(tw / 4),
                    )
                }
            }
            drawCircle(accent, radius = r, center = c, style = Stroke(width = m * 0.1f))
        }
        drawCircle(Color(0xFF9D7BFF), radius = r * 0.38f, center = c)
    }
}

@Composable
private fun DefaultLauncherDialog(vm: LauncherViewModel) {
    val g = LocalGlass.current
    val setDefault = LocalSetDefault.current
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .padding(28.dp)
                .widthIn(max = 360.dp)
                .glass(RoundedCornerShape(32.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SpinningGear(Modifier.size(72.dp).reveal(0), g.accent)
            GText(
                "Make EtherGear your home", 22.sp, FontWeight.SemiBold,
                modifier = Modifier.reveal(1), align = TextAlign.Center, maxLines = 2,
                glow = g.accent.copy(alpha = 0.5f),
            )
            GText(
                "Set it as your default launcher so the Home button always lands here. " +
                    "You can switch back to your old launcher any time in system settings.",
                14.sp, color = g.subtext, modifier = Modifier.reveal(2), align = TextAlign.Center, maxLines = 5,
            )
            Row(Modifier.reveal(3), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GChip("Not now", false) { vm.promptDismissed = true }
                GChip("Set as default", true) {
                    vm.promptDismissed = true
                    setDefault()
                }
            }
            GText(
                "Don't ask again", 12.sp, color = g.subtext,
                modifier = Modifier
                    .reveal(4)
                    .springClick(0.95f) { vm.prefs.updateSkipDefaultPrompt(true) }
                    .padding(6.dp),
            )
        }
    }
}

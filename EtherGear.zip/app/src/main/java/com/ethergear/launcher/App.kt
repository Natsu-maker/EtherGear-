package com.ethergear.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun EtherGearApp(vm: LauncherViewModel) {
    val prefs = vm.prefs
    val ctx = LocalContext.current

    BoxWithConstraints(Modifier.fillMaxSize().background(Color(0xFF05070D))) {
        val density = LocalDensity.current
        val wPx = with(density) { maxWidth.roundToPx() }
        val hPx = with(density) { maxHeight.roundToPx() }

        var backdrop by remember { mutableStateOf<Backdrop?>(null) }
        LaunchedEffect(wPx, hPx, prefs.wallpaperVersion) {
            backdrop = withContext(Dispatchers.Default) { WallpaperEngine.build(ctx, wPx, hPx) }
        }

        val glass = GlassTheme(prefs.dark, prefs.tint, Accents[prefs.accent.coerceIn(Accents.indices)])
        val mainFont = remember(prefs.fontMain, vm.fontTick) { FontStore.family(ctx, prefs.fontMain) }
        val clockFont = remember(prefs.fontClock, vm.fontTick) { FontStore.family(ctx, prefs.fontClock) }

        CompositionLocalProvider(
            LocalGlass provides glass,
            LocalBackdrop provides backdrop,
            LocalFont provides mainFont,
            LocalClockFont provides clockFont,
        ) {
            AppContent(vm)
        }
    }
}

@Composable
private fun AppContent(vm: LauncherViewModel) {
    val bd = LocalBackdrop.current

    BackHandler(enabled = vm.menu != null || vm.settingsOpen || vm.drawerOpen) {
        when {
            vm.menu != null -> vm.menu = null
            vm.settingsOpen -> vm.settingsOpen = false
            vm.drawerOpen -> vm.drawerOpen = false
        }
    }

    if (bd != null) {
        Image(bd.sharp, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
    }
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                listOf(Color.Black.copy(alpha = 0.35f), Color.Transparent, Color.Black.copy(alpha = 0.5f))
            )
        )
    )

    val progress by animateFloatAsState(
        if (vm.drawerOpen || vm.settingsOpen) 1f else 0f,
        spring(dampingRatio = 0.85f, stiffness = 300f),
        label = "homeDim",
    )
    Box(
        Modifier.fillMaxSize().graphicsLayer {
            val s = 1f - 0.05f * progress
            scaleX = s
            scaleY = s
            alpha = 1f - 0.6f * progress
        }
    ) { HomeLayer(vm) }

    AnimatedVisibility(
        visible = vm.drawerOpen,
        enter = slideInVertically(spring(dampingRatio = 0.9f, stiffness = 350f)) { it / 4 } + fadeIn(),
        exit = slideOutVertically(tween(220)) { it / 4 } + fadeOut(tween(200)),
    ) { DrawerLayer(vm) }

    AnimatedVisibility(
        visible = vm.settingsOpen,
        enter = fadeIn() + slideInVertically { it / 8 },
        exit = fadeOut() + slideOutVertically { it / 8 },
    ) { SettingsLayer(vm) }

    vm.menu?.let { MenuOverlay(it, vm) }
}

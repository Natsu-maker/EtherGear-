package com.ethergear.launcher

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.accessibility.AccessibilityEvent
import androidx.compose.runtime.mutableStateMapOf
import androidx.core.app.NotificationManagerCompat

/** Notification counts per package, shared with the UI. */
object Badges {
    val counts = mutableStateMapOf<String, Int>()
    private val main = Handler(Looper.getMainLooper())

    fun update(m: Map<String, Int>) {
        main.post {
            counts.clear()
            counts.putAll(m)
        }
    }
}

fun listenerEnabled(ctx: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

/** Needs "Notification access" turned on once. Powers badges and the music widget. */
class BadgeService : NotificationListenerService() {
    override fun onListenerConnected() {
        refresh()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        refresh()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        refresh()
    }

    private fun refresh() {
        val m = HashMap<String, Int>()
        try {
            val list = activeNotifications
            if (list != null) {
                for (n in list) {
                    if (n.isOngoing) continue
                    if ((n.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue
                    m[n.packageName] = (m[n.packageName] ?: 0) + 1
                }
            }
        } catch (_: Exception) {
        }
        Badges.update(m)
    }
}

/** Needs the accessibility toggle turned on once. Used only to lock the screen on double-tap. */
class LockService : AccessibilityService() {
    private var nav: NavOverlay? = null
    private var coverOn = false

    override fun onServiceConnected() {
        instance = this
        refreshNav()
    }

    /** Re-reads the gesture settings and shows or hides the touch strips. */
    fun refreshNav() {
        val sp = getSharedPreferences("ethergear", MODE_PRIVATE)
        if (sp.getBoolean("navGestures", false)) {
            val o = nav ?: NavOverlay(this).also { nav = it }
            o.show(sp.getBoolean("navPill", true))
            coverOn = sp.getBoolean("navCover", true)
            o.cover(false)
        } else {
            coverOn = false
            nav?.hide()
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (nav != null) refreshNav()
    }

    private fun cleanup() {
        nav?.hide()
        nav = null
        // Never leave the system bar hidden without the gestures that replace it.
        val sp = getSharedPreferences("ethergear", MODE_PRIVATE)
        if (sp.getBoolean("navHidden", false)) {
            setNavBarHidden(this, false)
            sp.edit().putBoolean("navHidden", false).apply()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!coverOn || event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == "com.android.systemui" || pkg == "android") return
        nav?.cover(pkg != packageName)
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: LockService? = null

        fun lock(): Boolean =
            instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) ?: false
    }
}

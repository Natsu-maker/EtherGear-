package com.ethergear.launcher

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.accessibility.AccessibilityEvent
import androidx.compose.runtime.mutableStateMapOf
import androidx.core.app.NotificationManagerCompat

/** Notification counts per package, shared with the UI. */
object Badges {
    val counts = mutableStateMapOf<String, Int>()
    private val main = Handler(Looper.getMainLooper())

    fun update(m: Map<String, Int>) {
        main.post {
            counts.clear()
            counts.putAll(m)
        }
    }
}

fun listenerEnabled(ctx: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

/** Needs "Notification access" turned on once. Powers badges and the music widget. */
class BadgeService : NotificationListenerService() {
    override fun onListenerConnected() {
        refresh()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        refresh()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        refresh()
    }

    private fun refresh() {
        val m = HashMap<String, Int>()
        try {
            val list = activeNotifications
            if (list != null) {
                for (n in list) {
                    if (n.isOngoing) continue
                    if ((n.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) continue
                    m[n.packageName] = (m[n.packageName] ?: 0) + 1
                }
            }
        } catch (_: Exception) {
        }
        Badges.update(m)
    }
}

/** Needs the accessibility toggle turned on once. Used only to lock the screen on double-tap. */
class LockService : AccessibilityService() {
    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: LockService? = null

        fun lock(): Boolean =
            instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) ?: false
    }
}

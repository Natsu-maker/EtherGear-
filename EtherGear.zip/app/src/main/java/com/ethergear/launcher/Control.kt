package com.ethergear.launcher

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import kotlinx.coroutines.delay
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

// ---------------------------------------------------------------------------------------------
// Tablet layout: app drawer on the left half, control center on the right half.
// ---------------------------------------------------------------------------------------------

@Composable
fun TabletPanels(vm: LauncherViewModel, progress: () -> Float) {
    val perf = LocalPerf.current
    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { vm.drawerOpen = false } }) {
        if (perf >= 2) Aurora(progress)
        Row(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .graphicsLayer {
                        val p = progress().coerceIn(0f, 1f)
                        translationX = -(1f - p) * size.width * 0.6f
                        if (perf >= 1) {
                            alpha = p
                            val s = 0.94f + 0.06f * p
                            scaleX = s
                            scaleY = s
                        }
                    }
                    .pointerInput(Unit) { detectTapGestures { } }
                    .glass(RoundedCornerShape(38.dp))
            ) { DrawerLayer(vm, compact = true) }

            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .graphicsLayer {
                        val p = progress().coerceIn(0f, 1f)
                        translationX = (1f - p) * size.width * 0.6f
                        if (perf >= 1) {
                            alpha = p
                            val s = 0.94f + 0.06f * p
                            scaleX = s
                            scaleY = s
                        }
                    }
                    .pointerInput(Unit) { detectTapGestures { } }
                    .glass(RoundedCornerShape(38.dp))
            ) { ControlCenter(vm) }
        }
    }
}

/** Two slow colour orbs drifting behind the panels (Full performance mode only). */
@Composable
private fun Aurora(progress: () -> Float) {
    val g = LocalGlass.current
    val t = rememberInfiniteTransition(label = "aurora")
    val a = t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse),
        label = "a"
    )
    Canvas(Modifier.fillMaxSize()) {
        val p = progress().coerceIn(0f, 1f)
        val v = a.value
        val r = size.minDimension * 0.6f
        val c1 = Offset(size.width * (0.15f + 0.3f * v), size.height * (0.2f + 0.25f * v))
        val c2 = Offset(size.width * (0.85f - 0.3f * v), size.height * (0.8f - 0.25f * v))
        drawCircle(
            Brush.radialGradient(listOf(g.accent.copy(alpha = 0.32f * p), Color.Transparent), c1, r),
            r, c1
        )
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF9D7BFF).copy(alpha = 0.30f * p), Color.Transparent), c2, r),
            r, c2
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Control center
// ---------------------------------------------------------------------------------------------

private class TileSpec(val label: String, val kind: Int, val active: Boolean, val click: () -> Unit)

private fun torchId(ctx: Context): String? = try {
    val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    cm.cameraIdList.firstOrNull {
        cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
    }
} catch (_: Exception) {
    null
}

@Composable
fun ControlCenter(vm: LauncherViewModel, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val prefs = vm.prefs

    // Torch (only if this device has a flash).
    val torch = remember { torchId(ctx) }
    var torchOn by remember { mutableStateOf(false) }
    DisposableEffect(torch) {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cb = object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                if (cameraId == torch) torchOn = enabled
            }
        }
        try {
            cm.registerTorchCallback(cb, null)
        } catch (_: Exception) {
        }
        onDispose {
            try {
                cm.unregisterTorchCallback(cb)
            } catch (_: Exception) {
            }
        }
    }

    // Volume (no permission needed).
    val audio = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var vol by remember {
        mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol)
    }

    // Brightness (needs the "modify system settings" permission, asked once).
    val canWrite = remember(vm.resumeTick) { Settings.System.canWrite(ctx) }
    var bright by remember {
        mutableFloatStateOf(
            try {
                Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
            } catch (_: Exception) {
                0.5f
            }
        )
    }

    val tiles = listOf(
        TileSpec("Internet", 0, false) {
            openSystemScreen(ctx, "android.settings.panel.action.INTERNET_CONNECTIVITY")
        },
        TileSpec("Bluetooth", 1, false) { openSystemScreen(ctx, Settings.ACTION_BLUETOOTH_SETTINGS) },
        if (torch != null) TileSpec("Torch", 2, torchOn) {
            try {
                (ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager).setTorchMode(torch, !torchOn)
            } catch (_: Exception) {
            }
        } else TileSpec("Display", 8, false) { openSystemScreen(ctx, Settings.ACTION_DISPLAY_SETTINGS) },
        TileSpec(if (prefs.dark) "Dark" else "Light", 3, prefs.dark) { prefs.updateDark(!prefs.dark) },
        TileSpec("Focus", 9, prefs.focusOn) { prefs.updateFocusOn(!prefs.focusOn) },
        TileSpec("Silence", 5, false) { openSystemScreen(ctx, "android.settings.ZEN_MODE_PRIORITY_SETTINGS") },
        TileSpec("Lock", 6, false) {
            if (!LockService.lock()) {
                Toast.makeText(ctx, "Turn on EtherGear double-tap lock in Accessibility first", Toast.LENGTH_LONG).show()
            }
        },
        TileSpec("Alerts", 7, false) { expandShade(ctx) },
    )

    Column(
        modifier
            .fillMaxSize()
            .drawBehind {
                val c = Offset(size.width * 0.9f, 0f)
                val r = size.width * 0.9f
                drawCircle(Brush.radialGradient(listOf(g.accent.copy(alpha = 0.26f), Color.Transparent), c, r), r, c)
            }
            .verticalScroll(rememberScrollState())
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(Modifier.fillMaxWidth().reveal(0), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                GText("Control Center", 24.sp, FontWeight.SemiBold, glow = g.accent.copy(alpha = 0.5f))
                GText("EtherGear", 11.sp, FontWeight.Medium, color = g.subtext, letterSpacing = 2.sp)
            }
            GChip("Settings", false) { vm.settingsOpen = true }
        }

        ControlHero(Modifier.reveal(1))

        GText("QUICK TOGGLES", 11.sp, FontWeight.SemiBold, color = g.accent, letterSpacing = 1.6.sp, modifier = Modifier.reveal(2))

        tiles.chunked(4).forEachIndexed { r, row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEachIndexed { i, t ->
                    Tile(t.label, t.kind, t.active, 2 + r * 4 + i, Modifier.weight(1f), t.click)
                }
            }
        }

        GText("LEVELS", 11.sp, FontWeight.SemiBold, color = g.accent, letterSpacing = 1.6.sp, modifier = Modifier.reveal(9))
        GlassSlider("Volume", 4, vol, 10) {
            vol = it
            try {
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * maxVol).roundToInt().coerceIn(0, maxVol), 0)
            } catch (_: Exception) {
            }
        }
        if (canWrite) {
            GlassSlider("Brightness", 8, bright, 11) {
                bright = it
                try {
                    val cr = ctx.contentResolver
                    Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, (it * 255).roundToInt().coerceIn(8, 255))
                } catch (_: Exception) {
                }
            }
        } else {
            Row(Modifier.reveal(11)) {
                GChip("Allow brightness control", true) {
                    try {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Exception) {
                    }
                }
            }
        }

        MusicCard(Modifier.reveal(12))
        DeviceCard(Modifier.reveal(13))
    }
}

@Composable
private fun PulseRing(color: Color, corner: Dp, modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "pulse")
    val p = t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1900, easing = LinearEasing), RepeatMode.Restart),
        label = "p"
    )
    Canvas(modifier) {
        val v = p.value
        val grow = v * 10.dp.toPx()
        drawRoundRect(
            color.copy(alpha = 0.5f * (1f - v)),
            topLeft = Offset(-grow, -grow),
            size = Size(size.width + 2 * grow, size.height + 2 * grow),
            cornerRadius = CornerRadius(corner.toPx() + grow),
            style = Stroke(2.dp.toPx()),
        )
    }
}

@Composable
private fun Tile(label: String, kind: Int, active: Boolean, index: Int, modifier: Modifier, onClick: () -> Unit) {
    val g = LocalGlass.current
    val perf = LocalPerf.current
    val fill by animateFloatAsState(
        if (active) 1f else 0f,
        spring(dampingRatio = 0.7f, stiffness = 380f),
        label = "tileFill"
    )
    val ink = if (fill > 0.5f) Color(0xFF06101A) else g.text
    Box(modifier.reveal(index).springClick(0.9f, onClick = onClick)) {
        if (active && perf >= 1) PulseRing(g.accent, 26.dp, Modifier.matchParentSize())
        Column(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.92f)
                .glass(RoundedCornerShape(26.dp))
                .drawBehind {
                    if (fill > 0.01f) {
                        drawRect(
                            Brush.verticalGradient(
                                listOf(g.accent.copy(alpha = 0.98f * fill), g.accent.copy(alpha = 0.70f * fill))
                            )
                        )
                    }
                },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(ink.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) { TileGlyph(kind, ink, Modifier.size(22.dp)) }
            Spacer(Modifier.height(8.dp))
            GText(label, 11.sp, FontWeight.Medium, color = ink)
        }
    }
}

@Composable
private fun GlassSlider(label: String, kind: Int, value: Float, index: Int, onChange: (Float) -> Unit) {
    val g = LocalGlass.current
    val cur by rememberUpdatedState(onChange)
    var w by remember { mutableFloatStateOf(1f) }
    val anim by animateFloatAsState(
        value.coerceIn(0f, 1f),
        spring(dampingRatio = 0.9f, stiffness = 600f),
        label = "slider"
    )
    val ink = if (anim > 0.3f) Color(0xFF06101A) else g.text
    Box(
        Modifier
            .reveal(index)
            .fillMaxWidth()
            .height(64.dp)
            .glass(RoundedCornerShape(32.dp))
            .onSizeChanged { w = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures { cur((it.x / w).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, _ ->
                    change.consume()
                    cur((change.position.x / w).coerceIn(0f, 1f))
                }
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(anim)
                .background(Brush.horizontalGradient(listOf(g.accent.copy(alpha = 0.45f), g.accent)))
        )
        Canvas(Modifier.fillMaxSize()) {
            val r = size.height * 0.28f
            val x = (size.width * anim - r * 1.5f).coerceIn(r * 1.5f, size.width - r * 1.5f)
            drawCircle(Color.Black.copy(alpha = 0.18f), r + 2.dp.toPx(), Offset(x, size.height / 2f + 1.dp.toPx()))
            drawCircle(Color.White.copy(alpha = 0.96f), r, Offset(x, size.height / 2f))
        }
        Row(Modifier.padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
            TileGlyph(kind, ink, Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            GText("$label  ${(anim * 100).roundToInt()}%", 14.sp, FontWeight.Medium, color = ink)
        }
    }
}

/** Big time + date with a soft accent glow and a battery pill. */
@Composable
private fun ControlHero(modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val is24 = remember { android.text.format.DateFormat.is24HourFormat(ctx) }
    var now by remember { mutableStateOf(java.time.LocalDateTime.now()) }
    var bat by remember { mutableIntStateOf(readBattery(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            now = java.time.LocalDateTime.now()
            bat = readBattery(ctx)
            delay(((60 - now.second) * 1000L).coerceIn(1000L, 20_000L))
        }
    }
    val time = now.format(java.time.format.DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm"))
    val date = now.format(java.time.format.DateTimeFormatter.ofPattern("EEEE, d MMMM"))
    val batAnim by animateFloatAsState(bat.coerceIn(0, 100) / 100f, spring(dampingRatio = 0.8f, stiffness = 120f), label = "heroBat")
    Row(
        modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(32.dp))
            .drawBehind {
                val c = Offset(size.width * 0.15f, size.height * 0.2f)
                val r = size.width * 0.6f
                drawCircle(Brush.radialGradient(listOf(g.accent.copy(alpha = 0.30f), Color.Transparent), c, r), r, c)
            }
            .padding(horizontal = 24.dp, vertical = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            GText(time, 60.sp, FontWeight.Light, clock = true, glow = g.accent.copy(alpha = 0.6f), letterSpacing = (-1).sp)
            GText(date, 14.sp, FontWeight.Medium, color = g.subtext)
        }
        if (bat >= 0) {
            Column(horizontalAlignment = Alignment.End) {
                GText("$bat%", 18.sp, FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier.width(54.dp).height(8.dp).clip(RoundedCornerShape(50)).background(g.text.copy(alpha = 0.18f))
                ) { Box(Modifier.fillMaxHeight().fillMaxWidth(batAnim).background(g.accent)) }
            }
        }
    }
}

/** Small hand-drawn icons: 0 wifi, 1 bluetooth, 2 torch, 3 moon, 4 speaker, 5 no-disturb, 6 lock, 7 alerts, 8 sun. */
@Composable
private fun TileGlyph(kind: Int, color: Color, modifier: Modifier) {
    Canvas(modifier) {
        val s = size.minDimension
        val sw = s * 0.09f
        val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            0 -> {
                for (i in 1..3) {
                    val r = s * (0.14f + 0.17f * i)
                    drawArc(
                        color, -135f, 90f, false,
                        Offset(s * 0.5f - r, s * 0.85f - r), Size(2 * r, 2 * r), style = st
                    )
                }
                drawCircle(color, s * 0.07f, Offset(s * 0.5f, s * 0.85f))
            }
            1 -> {
                val p = Path().apply {
                    moveTo(s * 0.3f, s * 0.3f); lineTo(s * 0.7f, s * 0.7f); lineTo(s * 0.5f, s * 0.9f)
                    lineTo(s * 0.5f, s * 0.1f); lineTo(s * 0.7f, s * 0.3f); lineTo(s * 0.3f, s * 0.7f)
                }
                drawPath(p, color, style = st)
            }
            2 -> {
                val p = Path().apply {
                    moveTo(s * 0.58f, s * 0.04f); lineTo(s * 0.22f, s * 0.56f); lineTo(s * 0.47f, s * 0.56f)
                    lineTo(s * 0.4f, s * 0.96f); lineTo(s * 0.78f, s * 0.4f); lineTo(s * 0.53f, s * 0.4f); close()
                }
                drawPath(p, color)
            }
            3 -> {
                val a = Path().apply { addOval(Rect(Offset(s * 0.15f, s * 0.1f), Size(s * 0.7f, s * 0.8f))) }
                val b = Path().apply { addOval(Rect(Offset(s * 0.42f, s * 0.0f), Size(s * 0.65f, s * 0.75f))) }
                drawPath(Path.combine(PathOperation.Difference, a, b), color)
            }
            4 -> {
                val p = Path().apply {
                    moveTo(s * 0.1f, s * 0.38f); lineTo(s * 0.3f, s * 0.38f); lineTo(s * 0.52f, s * 0.18f)
                    lineTo(s * 0.52f, s * 0.82f); lineTo(s * 0.3f, s * 0.62f); lineTo(s * 0.1f, s * 0.62f); close()
                }
                drawPath(p, color)
                drawArc(color, -40f, 80f, false, Offset(s * 0.4f, s * 0.3f), Size(s * 0.4f, s * 0.4f), style = st)
                drawArc(color, -55f, 110f, false, Offset(s * 0.3f, s * 0.15f), Size(s * 0.6f, s * 0.7f), style = st)
            }
            5 -> {
                drawCircle(color, s * 0.4f, Offset(s * 0.5f, s * 0.5f), style = st)
                drawLine(color, Offset(s * 0.3f, s * 0.5f), Offset(s * 0.7f, s * 0.5f), strokeWidth = sw, cap = StrokeCap.Round)
            }
            6 -> {
                drawRoundRect(color, Offset(s * 0.2f, s * 0.45f), Size(s * 0.6f, s * 0.45f), CornerRadius(s * 0.1f))
                drawArc(color, 180f, 180f, false, Offset(s * 0.3f, s * 0.1f), Size(s * 0.4f, s * 0.5f), style = st)
            }
            7 -> {
                val p1 = Path().apply { moveTo(s * 0.2f, s * 0.25f); lineTo(s * 0.5f, s * 0.5f); lineTo(s * 0.8f, s * 0.25f) }
                val p2 = Path().apply { moveTo(s * 0.2f, s * 0.55f); lineTo(s * 0.5f, s * 0.8f); lineTo(s * 0.8f, s * 0.55f) }
                drawPath(p1, color, style = st)
                drawPath(p2, color, style = st)
            }
            9 -> {
                drawCircle(color, s * 0.4f, Offset(s * 0.5f, s * 0.5f), style = st)
                drawCircle(color, s * 0.14f, Offset(s * 0.5f, s * 0.5f))
            }
            else -> {
                drawCircle(color, s * 0.2f, Offset(s * 0.5f, s * 0.5f))
                for (i in 0 until 8) {
                    val ang = i * PI / 4
                    val c = cos(ang).toFloat()
                    val d = sin(ang).toFloat()
                    drawLine(
                        color,
                        Offset(s * 0.5f + c * s * 0.32f, s * 0.5f + d * s * 0.32f),
                        Offset(s * 0.5f + c * s * 0.45f, s * 0.5f + d * s * 0.45f),
                        strokeWidth = sw, cap = StrokeCap.Round,
                    )
                }
            }
        }
    }
}

package com.ethergear.launcher

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Full-screen list for hiding bloatware: flip a switch to remove an app from the launcher. */
@Composable
fun BloatLayer(vm: LauncherViewModel) {
    val g = LocalGlass.current
    val bd = LocalBackdrop.current
    val ctx = LocalContext.current
    val prefs = vm.prefs
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) } // 0 all, 1 system, 2 installed, 3 hidden

    val shown = remember(vm.apps, query, filter, prefs.hidden) {
        val q = query.trim().lowercase()
        vm.apps.filter { e ->
            (q.isEmpty() || e.label.lowercase().contains(q) || e.pkg.lowercase().contains(q)) &&
                when (filter) {
                    1 -> e.system
                    2 -> !e.system
                    3 -> e.pkg in prefs.hidden
                    else -> true
                }
        }
    }

    // "Hide all shown" never touches your dock apps or the Settings app.
    val essential = remember(vm.apps, prefs.dock) {
        val s = HashSet<String>(prefs.dock)
        try {
            ctx.packageManager.resolveActivity(Intent(Settings.ACTION_SETTINGS), 0)
                ?.activityInfo?.packageName?.let { s.add(it) }
        } catch (_: Exception) {
        }
        s
    }
    val systemCount = vm.apps.count { it.system }

    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }) {
        if (bd != null) {
            Image(
                bd.blurred, null, Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds, filterQuality = FilterQuality.Low,
            )
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = if (g.dark) 0.6f else 0.35f)))

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(Modifier.fillMaxWidth().reveal(0), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    GText(
                        "Hide apps", 26.sp, FontWeight.SemiBold,
                        color = Color.White, glow = g.accent.copy(alpha = 0.5f)
                    )
                    GText(
                        "${prefs.hidden.size} hidden  ·  ${vm.apps.size} apps  ·  $systemCount system",
                        13.sp, color = Color.White.copy(alpha = 0.7f),
                    )
                }
                GChip("Done", true) { vm.bloatOpen = false }
            }
            GText(
                "Flip a switch to hide an app. Hidden apps stay installed, they just disappear from EtherGear.",
                13.sp, color = Color.White.copy(alpha = 0.7f), maxLines = 2, modifier = Modifier.reveal(1),
            )

            Row(
                Modifier
                    .reveal(2)
                    .fillMaxWidth()
                    .height(48.dp)
                    .glass(RoundedCornerShape(24.dp))
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SearchGlyph(g.subtext, Modifier.size(18.dp))
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) GText("Search apps", 15.sp, color = g.subtext)
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = g.text, fontSize = 15.sp, fontFamily = LocalFont.current),
                        cursorBrush = SolidColor(g.accent),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            Row(
                Modifier.reveal(3).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                GChip("All", filter == 0) { filter = 0 }
                GChip("System", filter == 1) { filter = 1 }
                GChip("Installed", filter == 2) { filter = 2 }
                GChip("Hidden", filter == 3) { filter = 3 }
                GChip("Hide all shown", false) {
                    vm.hideMany(shown.map { it.pkg }.filter { it !in essential })
                }
                GChip("Show all shown", false) { vm.showMany(shown.map { it.pkg }) }
            }
            GText(
                "\"Hide all shown\" skips your dock apps and Settings.",
                11.sp, color = Color.White.copy(alpha = 0.55f),
            )

            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .reveal(4)
                    .glass(RoundedCornerShape(26.dp))
            ) {
                if (shown.isEmpty()) {
                    GText(
                        "No apps match.", 14.sp, color = g.subtext,
                        modifier = Modifier.align(Alignment.Center),
                    )
                }
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 8.dp),
                ) {
                    items(shown, key = { it.pkg }) { e ->
                        val isHidden = e.pkg in prefs.hidden
                        val toggle = { if (isHidden) vm.unhide(e.pkg) else vm.hide(e.pkg) }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .springClick(0.98f) { toggle() }
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Image(
                                e.icon, e.label,
                                Modifier.size(40.dp).clip(RoundedCornerShape(12.dp))
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                GText(
                                    if (e.system) "${e.label}  ·  system" else e.label,
                                    15.sp, FontWeight.Medium,
                                )
                                GText(e.pkg, 11.sp, color = g.subtext)
                            }
                            Switch(
                                checked = isHidden,
                                onCheckedChange = { toggle() },
                                colors = SwitchDefaults.colors(
                                    checkedTrackColor = g.accent,
                                    checkedThumbColor = Color.White,
                                    uncheckedTrackColor = g.text.copy(alpha = 0.2f),
                                    uncheckedThumbColor = g.text.copy(alpha = 0.7f),
                                    uncheckedBorderColor = Color.Transparent,
                                ),
                            )
                        }
                    }
                }
            }
        }
    }
}

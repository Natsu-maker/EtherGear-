@file:OptIn(ExperimentalFoundationApi::class)

package com.ethergear.launcher

import android.content.res.Configuration
import android.text.format.DateFormat
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.max

@Composable
fun AppCell(
    entry: AppEntry,
    prefs: Prefs,
    showLabel: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = IconShapes[prefs.shape.coerceIn(IconShapes.indices)].second
    Column(
        modifier
            .springClick(onLongClick = onLongClick, onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            bitmap = entry.icon,
            contentDescription = entry.label,
            modifier = Modifier.size(prefs.iconSize.dp).clip(shape),
        )
        if (showLabel && prefs.showLabels) {
            GText(
                entry.label, 11.sp, FontWeight.Medium,
                modifier = Modifier.padding(top = 5.dp).widthIn(max = 76.dp),
                color = Color.White, shadow = true, align = TextAlign.Center,
            )
        }
    }
}

private fun readBattery(ctx: Context): Int {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
    val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
    return if (l >= 0 && s > 0) l * 100 / s else -1
}

@Composable
fun ClockCard(vm: LauncherViewModel, compact: Boolean, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val is24 = remember { DateFormat.is24HourFormat(ctx) }
    val timeFmt = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm") }
    val dateFmt = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var bat by remember { mutableIntStateOf(readBattery(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            bat = readBattery(ctx)
            delay(5_000)
        }
    }
    Row(
        modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(30.dp))
            .springClick(0.98f, onLongClick = { vm.settingsOpen = true }) { }
            .padding(horizontal = 22.dp, vertical = if (compact) 12.dp else 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            GText(
                now.format(timeFmt), if (compact) 40.sp else 60.sp, FontWeight.Light,
                clock = true, glow = g.accent.copy(alpha = 0.55f), letterSpacing = (-1).sp,
            )
            GText(now.format(dateFmt), 14.sp, FontWeight.Medium, color = g.subtext)
        }
        Column(horizontalAlignment = Alignment.End) {
            if (bat >= 0) {
                GText("$bat%", 13.sp, FontWeight.SemiBold, color = g.subtext)
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier.width(44.dp).height(8.dp).clip(RoundedCornerShape(50))
                        .background(g.text.copy(alpha = 0.18f))
                ) {
                    Box(
                        Modifier.fillMaxHeight().fillMaxWidth(bat.coerceIn(0, 100) / 100f)
                            .background(g.accent)
                    )
                }
                Spacer(Modifier.height(10.dp))
            }
            Box(
                Modifier.size(38.dp).glass(CircleShape).springClick { vm.settingsOpen = true },
                contentAlignment = Alignment.Center,
            ) { SlidersGlyph(g.text, Modifier.size(20.dp)) }
        }
    }
}

@Composable
private fun PageDots(count: Int, current: Int) {
    val g = LocalGlass.current
    if (count <= 1) return
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (i in 0 until count) {
            val w by animateDpAsState(if (i == current) 20.dp else 7.dp, label = "dot")
            Box(
                Modifier.padding(horizontal = 3.dp).width(w).height(7.dp).clip(CircleShape)
                    .background(if (i == current) g.accent else Color.White.copy(alpha = 0.4f))
            )
        }
    }
}

@Composable
fun HomeLayer(vm: LauncherViewModel) {
    val prefs = vm.prefs
    val ctx = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val cols = if (landscape) 7 else prefs.columns
    val rows = if (landscape) 3 else 5
    val perPage = cols * rows

    val entries = prefs.homeApps.mapNotNull { vm.appMap[it] }.filter { it.pkg !in prefs.hidden }
    val pageCount = max(1, (entries.size + perPage - 1) / perPage)
    val pagerState = rememberPagerState { pageCount }
    LaunchedEffect(vm.homeSignal) { pagerState.animateScrollToPage(0) }

    val dockEntries = prefs.dock.mapNotNull { vm.appMap[it] }.filter { it.pkg !in prefs.hidden }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragCancel = { total = 0f },
                    onDragEnd = {
                        if (total < -110f) vm.drawerOpen = true
                        else if (total > 110f) expandShade(ctx)
                        total = 0f
                    },
                ) { _, dy -> total += dy }
            }
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            ClockCard(vm, landscape, Modifier.padding(horizontal = 16.dp, vertical = 12.dp))
            HorizontalPager(pagerState, Modifier.weight(1f).fillMaxWidth()) { page ->
                val items = entries.drop(page * perPage).take(perPage)
                Column(Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
                    for (r in 0 until rows) {
                        Row(Modifier.weight(1f).fillMaxWidth()) {
                            for (c in 0 until cols) {
                                val item = items.getOrNull(r * cols + c)
                                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                                    if (item != null) {
                                        AppCell(
                                            item, prefs, true,
                                            onClick = { launchApp(ctx, item) },
                                            onLongClick = { vm.menu = item },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            PageDots(pageCount, pagerState.currentPage)
            Row(
                Modifier
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(34.dp))
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (dockEntries.isEmpty()) {
                    GText(
                        "Long-press an app, then \"Add to dock\"", 13.sp,
                        color = LocalGlass.current.subtext, modifier = Modifier.padding(vertical = 18.dp)
                    )
                } else {
                    dockEntries.forEach { item ->
                        AppCell(
                            item, prefs, false,
                            onClick = { launchApp(ctx, item) },
                            onLongClick = { vm.menu = item },
                        )
                    }
                }
            }
        }
    }
}

@file:OptIn(ExperimentalFoundationApi::class)

package com.ethergear.launcher

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.os.BatteryManager
import android.text.format.DateFormat
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.drop
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
private fun BadgeBubble(n: Int, modifier: Modifier) {
    val g = LocalGlass.current
    Box(
        modifier
            .defaultMinSize(18.dp, 18.dp)
            .clip(CircleShape)
            .background(g.accent)
            .padding(horizontal = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        GText(if (n > 9) "9+" else "$n", 10.sp, FontWeight.Bold, color = Color(0xFF06101A))
    }
}

@Composable
private fun LockGlyph(modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawCircle(Color.Black.copy(alpha = 0.55f))
        val bw = w * 0.42f
        val bh = h * 0.3f
        drawRoundRect(Color.White, Offset(w / 2 - bw / 2, h * 0.48f), Size(bw, bh), CornerRadius(3f))
        drawArc(
            Color.White, 180f, 180f, false,
            Offset(w / 2 - bw * 0.32f, h * 0.26f), Size(bw * 0.64f, h * 0.4f),
            style = Stroke(width = w * 0.09f),
        )
    }
}

@Composable
fun AppCell(
    entry: AppEntry,
    prefs: Prefs,
    showLabel: Boolean,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier,
    afterLaunch: () -> Unit = {},
    editing: Boolean = false,
    subtitle: String? = null,
) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val auth = LocalAuth.current
    val bounds = remember { IntArray(4) }
    val shape = IconShapes[prefs.shape.coerceIn(IconShapes.indices)].second
    val badge = if (prefs.badgesOn) (Badges.counts[entry.pkg] ?: 0) else 0
    val locked = entry.pkg in prefs.locked
    Column(
        modifier
            .onGloballyPositioned { c ->
                val p = c.positionInRoot()
                bounds[0] = p.x.roundToInt()
                bounds[1] = p.y.roundToInt()
                bounds[2] = bounds[0] + c.size.width
                bounds[3] = bounds[1] + c.size.height
            }
            .springClick(onLongClick = onLongClick) {
                if (!editing) {
                    val go = {
                        launchApp(ctx, entry, view, bounds)
                        afterLaunch()
                    }
                    if (locked) auth("Unlock ${entry.label}", go) else go()
                }
            }
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box {
            Image(
                bitmap = entry.icon,
                contentDescription = entry.label,
                modifier = Modifier.size(prefs.iconSize.dp).clip(shape),
            )
            if (badge > 0) {
                BadgeBubble(badge, Modifier.align(Alignment.TopEnd).offset(5.dp, (-5).dp))
            }
            if (locked) {
                LockGlyph(Modifier.align(Alignment.BottomEnd).size(16.dp))
            }
        }
        if (showLabel && prefs.showLabels) {
            GText(
                entry.label, 11.sp, FontWeight.Medium,
                modifier = Modifier.padding(top = 5.dp).widthIn(max = 76.dp),
                color = Color.White, shadow = true, align = TextAlign.Center,
            )
        }
        if (subtitle != null) {
            GText(
                subtitle, 10.sp, FontWeight.Medium,
                color = Color.White.copy(alpha = 0.7f), align = TextAlign.Center,
            )
        }
    }
}

internal fun readBattery(ctx: Context): Int {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
    val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
    return if (l >= 0 && s > 0) l * 100 / s else -1
}

@Composable
fun ClockCard(vm: LauncherViewModel, compact: Boolean, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val is24 = remember { DateFormat.is24HourFormat(ctx) }
    val timeFmt = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm") }
    val dateFmt = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()) }
    var timeStr by remember { mutableStateOf(LocalDateTime.now().format(timeFmt)) }
    var dateStr by remember { mutableStateOf(LocalDateTime.now().format(dateFmt)) }
    var bat by remember { mutableIntStateOf(readBattery(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            val n = LocalDateTime.now()
            timeStr = n.format(timeFmt)
            dateStr = n.format(dateFmt)
            bat = readBattery(ctx)
            delay(((60 - n.second) * 1000L).coerceIn(1000L, 20_000L))
        }
    }
    val batAnim by animateFloatAsState(
        bat.coerceIn(0, 100) / 100f,
        spring(dampingRatio = 0.8f, stiffness = 120f),
        label = "battery"
    )

    // A light sweeps around the card each time Home is shown.
    val shine = remember { Animatable(0f) }
    LaunchedEffect(vm.homeSignal) {
        shine.snapTo(0f)
        delay(450)
        shine.animateTo(1f, tween(1500, easing = FastOutSlowInEasing))
    }

    Row(
        modifier
            .fillMaxWidth()
            .springClick(0.98f, onLongClick = { vm.settingsOpen = true }) { }
            .glass(RoundedCornerShape(30.dp))
            .introShine({ shine.value }, 30.dp)
            .padding(horizontal = 22.dp, vertical = if (compact) 12.dp else 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            AnimatedContent(
                targetState = timeStr,
                transitionSpec = {
                    (slideInVertically(tween(340, easing = FastOutSlowInEasing)) { it / 2 } + fadeIn(tween(240))) togetherWith
                        (slideOutVertically(tween(240)) { -it / 2 } + fadeOut(tween(160)))
                },
                label = "clockDigits",
            ) { t ->
                GText(
                    t, if (compact) 40.sp else 60.sp, FontWeight.Light,
                    clock = true, glow = g.accent.copy(alpha = 0.55f), letterSpacing = (-1).sp,
                )
            }
            GText(dateStr, 14.sp, FontWeight.Medium, color = g.subtext)
        }
        Column(horizontalAlignment = Alignment.End) {
            if (bat >= 0) {
                GText("$bat%", 13.sp, FontWeight.SemiBold, color = g.subtext)
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier.width(44.dp).height(8.dp).clip(RoundedCornerShape(50))
                        .background(g.text.copy(alpha = 0.18f))
                ) {
                    Box(
                        Modifier.fillMaxHeight().fillMaxWidth(batAnim).background(g.accent)
                    )
                }
                Spacer(Modifier.height(10.dp))
            }
            Box(
                Modifier.size(38.dp).springClick { vm.settingsOpen = true }.glass(CircleShape),
                contentAlignment = Alignment.Center,
            ) { SlidersGlyph(g.text, Modifier.size(20.dp)) }
        }
    }
}

@Composable
private fun PageDots(count: Int, current: Int) {
    val g = LocalGlass.current
    if (count <= 1) return
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (i in 0 until count) {
            val w by animateDpAsState(
                if (i == current) 20.dp else 7.dp,
                spring(dampingRatio = 0.6f, stiffness = 400f),
                label = "dot"
            )
            val a by animateFloatAsState(if (i == current) 1f else 0.4f, label = "dotAlpha")
            Box(
                Modifier.padding(horizontal = 3.dp).width(w).height(7.dp).clip(CircleShape)
                    .background(if (i == current) g.accent else Color.White.copy(alpha = a))
            )
        }
    }
}

@Composable
fun HomeLayer(vm: LauncherViewModel) {
    val prefs = vm.prefs
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val conf = LocalConfiguration.current
    val landscape = conf.orientation == Configuration.ORIENTATION_LANDSCAPE
    val screenH = conf.screenHeightDp * LocalDensity.current.density
    val cols = if (landscape) 7 else prefs.columns
    val rows = if (landscape) 3 else 5
    val perPage = cols * rows

    val items: List<HomeItem> = remember(prefs.homeApps, prefs.folders, prefs.hidden, vm.appMap) {
        prefs.homeApps.mapNotNull<String, HomeItem> { t ->
            if (t.startsWith("f:")) {
                val f = prefs.folders[t.removePrefix("f:")] ?: return@mapNotNull null
                val m = f.apps.mapNotNull { vm.appMap[it] }.filter { it.pkg !in prefs.hidden }
                if (m.isEmpty()) null else FolderItem(f, m)
            } else {
                vm.appMap[t]?.takeIf { it.pkg !in prefs.hidden }?.let { AppItem(it) }
            }
        }
    }
    val visibleTokens = remember(items) { items.map { it.token } }
    val currentItems by rememberUpdatedState(items)
    val currentTokens by rememberUpdatedState(visibleTokens)
    val dockEntries = remember(prefs.dock, prefs.hidden, vm.appMap) {
        prefs.dock.mapNotNull { vm.appMap[it] }.filter { it.pkg !in prefs.hidden }
    }

    // Page 0 is the widgets page (when enabled); app pages follow.
    val lead = if (prefs.widgetsPage) 1 else 0
    val appPages = max(1, (items.size + perPage - 1) / perPage)
    val total = appPages + lead
    val pagerState = rememberPagerState(initialPage = lead) { total }

    LaunchedEffect(vm.homeSignal) { if (vm.homeSignal > 0) pagerState.animateScrollToPage(lead) }
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.drop(1).collect {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
    }
    LaunchedEffect(pagerState) {
        snapshotFlow {
            val c = pagerState.pageCount
            if (c > 1) ((pagerState.currentPage + pagerState.currentPageOffsetFraction) / (c - 1)).coerceIn(0f, 1f)
            else 0.5f
        }.collect { vm.pageFrac = it }
    }

    // A light sweeps along the dock every few seconds.
    val dockShine = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(2200)
        while (true) {
            dockShine.snapTo(0f)
            dockShine.animateTo(1f, tween(1700, easing = LinearOutSlowInEasing))
            delay(8000)
        }
    }

    // Icons wiggle while you rearrange.
    val wig = remember { Animatable(0f) }
    LaunchedEffect(vm.editMode) {
        if (vm.editMode) {
            while (true) {
                wig.animateTo(1f, tween(120, easing = LinearEasing))
                wig.animateTo(-1f, tween(120, easing = LinearEasing))
            }
        } else {
            wig.snapTo(0f)
        }
    }

    // ---- Drag & drop state ----
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragPos by remember { mutableStateOf(Offset.Zero) }
    var hoverIdx by remember { mutableIntStateOf(-1) }
    val cellRects = remember { HashMap<Int, Rect>() }

    fun hitIndex(p: Offset): Int {
        for ((k, r) in cellRects) if (r.contains(p)) return k
        return -1
    }

    // Dropping on the middle of another item merges; dropping elsewhere reorders.
    fun mergeTarget(p: Offset, dragged: String): Int {
        if (dragged.startsWith("f:")) return -1
        val idx = hitIndex(p)
        if (idx < 0) return -1
        val r = cellRects[idx] ?: return -1
        val t = currentItems.getOrNull(idx) ?: return -1
        if (t.token == dragged) return -1
        val inner = Rect(
            r.center - Offset(r.width * 0.25f, r.height * 0.25f),
            Size(r.width * 0.5f, r.height * 0.5f)
        )
        return if (inner.contains(p)) idx else -1
    }

    fun finishDrag(token: String) {
        val idx = hitIndex(dragPos)
        if (idx >= 0) {
            val mt = mergeTarget(dragPos, token)
            val target = if (mt >= 0) currentItems.getOrNull(mt) else null
            if (target != null) vm.mergeIntoFolder(token, target.token)
            else vm.moveHomeItem(token, idx, currentTokens)
        }
        dragKey = null
        hoverIdx = -1
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total0 = 0f
                var lastDy = 0f
                var ticked = false
                detectVerticalDragGestures(
                    onDragStart = { total0 = 0f; lastDy = 0f; ticked = false },
                    onDragCancel = { if (vm.dragging) vm.dragging = false },
                    onDragEnd = {
                        if (vm.dragging) {
                            val open = vm.dragP > 0.35f || (lastDy < -10f && vm.dragP > 0.08f)
                            vm.drawerOpen = open
                            vm.dragging = false
                        } else if (total0 > 110f) {
                            expandShade(ctx)
                        }
                    },
                ) { _, dy ->
                    total0 += dy
                    lastDy = dy
                    if (total0 < 0f && !vm.editMode) {
                        vm.dragging = true
                        vm.dragP = (-total0 / (screenH * 0.5f)).coerceIn(0f, 1f)
                        if (vm.dragP >= 0.35f && !ticked) {
                            ticked = true
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        } else if (vm.dragP < 0.35f) ticked = false
                    }
                }
            }
            .pointerInput(prefs.doubleTapLock) {
                detectTapGestures(
                    onLongPress = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        vm.editMode = true
                    },
                    onDoubleTap = {
                        if (prefs.doubleTapLock && !LockService.lock()) {
                            Toast.makeText(
                                ctx, "Turn on EtherGear double-tap lock in Settings first", Toast.LENGTH_LONG
                            ).show()
                        }
                    },
                )
            }
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            ClockCard(
                vm, landscape,
                Modifier.padding(horizontal = 16.dp, vertical = 12.dp).reveal(0, vm.homeSignal)
            )
            HorizontalPager(
                pagerState,
                Modifier.weight(1f).fillMaxWidth(),
                userScrollEnabled = dragKey == null,
            ) { page ->
                val pageMod = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val off = (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
                        val a = abs(off).coerceIn(0f, 1f)
                        alpha = 1f - 0.55f * a
                        val s = 1f - 0.1f * a
                        scaleX = s
                        scaleY = s
                        rotationY = off * 14f
                        cameraDistance = 14f * density
                    }
                if (lead == 1 && page == 0) {
                    WidgetsPage(vm, pageMod)
                } else {
                    val pi = page - lead
                    Column(pageMod.padding(horizontal = 8.dp)) {
                        for (r in 0 until rows) {
                            Row(Modifier.weight(1f).fillMaxWidth()) {
                                for (c in 0 until cols) {
                                    val flat = pi * perPage + r * cols + c
                                    val item = items.getOrNull(flat)
                                    val cellMod = Modifier
                                        .reveal(1 + r + c, vm.homeSignal)
                                        .graphicsLayer {
                                            if (vm.editMode) {
                                                rotationZ = wig.value * (if ((r + c) % 2 == 0) 1.6f else -1.6f)
                                            }
                                            alpha = if (dragKey != null && dragKey == item?.token) 0.25f else 1f
                                            if (hoverIdx == flat) {
                                                scaleX = 1.14f
                                                scaleY = 1.14f
                                            }
                                        }
                                    Box(
                                        Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                            .onGloballyPositioned {
                                                cellRects[flat] = Rect(it.positionInRoot(), it.size.toSize())
                                            }
                                            .pointerInput(item?.token, vm.editMode) {
                                                if (vm.editMode && item != null) {
                                                    detectDragGestures(
                                                        onDragStart = { off ->
                                                            val rect = cellRects[flat]
                                                            if (rect != null) {
                                                                dragKey = item.token
                                                                dragPos = rect.topLeft + off
                                                                hoverIdx = -1
                                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                            }
                                                        },
                                                        onDrag = { change, amount ->
                                                            change.consume()
                                                            if (dragKey != null) {
                                                                dragPos += amount
                                                                val h = mergeTarget(dragPos, item.token)
                                                                if (h != hoverIdx) {
                                                                    hoverIdx = h
                                                                    if (h >= 0) {
                                                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                                    }
                                                                }
                                                            }
                                                        },
                                                        onDragEnd = { if (dragKey != null) finishDrag(item.token) },
                                                        onDragCancel = {
                                                            dragKey = null
                                                            hoverIdx = -1
                                                        },
                                                    )
                                                }
                                            },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        when (item) {
                                            is AppItem -> AppCell(
                                                item.entry, prefs, true,
                                                onLongClick = { vm.menu = item.entry },
                                                modifier = cellMod,
                                                editing = vm.editMode,
                                            )
                                            is FolderItem -> FolderCell(
                                                item, prefs,
                                                onClick = { if (!vm.editMode) vm.openFolder = item.folder.id },
                                                onLongClick = {
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    vm.editMode = true
                                                },
                                                modifier = cellMod,
                                            )
                                            null -> {}
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = vm.editMode,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically(),
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    GText(
                        "Drag to move. Drop onto an app to make a folder.", 12.sp,
                        color = Color.White.copy(alpha = 0.75f), modifier = Modifier.weight(1f, fill = false),
                    )
                    Spacer(Modifier.width(10.dp))
                    GChip("Done", true) { vm.editMode = false }
                }
            }
            PageDots(total, pagerState.currentPage)
            Row(
                Modifier
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .reveal(9, vm.homeSignal)
                    .fillMaxWidth()
                    .glass(RoundedCornerShape(34.dp))
                    .introShine({ dockShine.value }, 34.dp, 0.55f)
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (dockEntries.isEmpty()) {
                    GText(
                        "Long-press an app, then \"Add to dock\"", 13.sp,
                        color = LocalGlass.current.subtext, modifier = Modifier.padding(vertical = 18.dp)
                    )
                } else {
                    dockEntries.forEach { item ->
                        AppCell(
                            item, prefs, false,
                            onLongClick = { vm.menu = item },
                            editing = vm.editMode,
                        )
                    }
                }
            }
        }

        // The item you are dragging floats under your finger.
        val dk = dragKey
        if (dk != null) {
            val di = currentItems.firstOrNull { it.token == dk }
            if (di != null) {
                Box(
                    Modifier
                        .offset {
                            val half = (prefs.iconSize / 2f).dp.toPx()
                            IntOffset((dragPos.x - half).roundToInt(), (dragPos.y - half).roundToInt())
                        }
                        .graphicsLayer {
                            scaleX = 1.15f
                            scaleY = 1.15f
                            alpha = 0.95f
                        }
                ) {
                    when (di) {
                        is AppItem -> Image(
                            di.entry.icon, null,
                            Modifier.size(prefs.iconSize.dp)
                                .clip(IconShapes[prefs.shape.coerceIn(IconShapes.indices)].second)
                        )
                        is FolderItem -> FolderGlyph(di, prefs)
                    }
                }
            }
        }
    }
}

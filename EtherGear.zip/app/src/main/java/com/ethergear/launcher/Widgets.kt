package com.ethergear.launcher

import android.app.ActivityManager
import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.provider.Settings
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

fun openSystemScreen(ctx: Context, action: String) {
    try {
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
    }
}

fun hasUsageAccess(ctx: Context): Boolean {
    return try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        mode == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) {
        false
    }
}

/** Foreground time in the last 7 days, per package, in milliseconds. */
fun weeklyUsage(ctx: Context): Map<String, Long> {
    return try {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
        val end = System.currentTimeMillis()
        usm.queryAndAggregateUsageStats(end - 7L * 24 * 3600 * 1000, end)
            .mapValues { it.value.totalTimeInForeground }
    } catch (_: Exception) {
        emptyMap()
    }
}

private fun fmtPlaytime(ms: Long): String? {
    val m = ms / 60000
    return when {
        m <= 0 -> null
        m >= 60 -> "${m / 60}h ${m % 60}m"
        else -> "${m}m"
    }
}

@Composable
fun WidgetsPage(vm: LauncherViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        DeviceCard(Modifier.reveal(0, vm.homeSignal))
        MusicCard(Modifier.reveal(1, vm.homeSignal))
        GameShelf(vm, Modifier.reveal(2, vm.homeSignal))
    }
}

@Composable
private fun Ring(label: String, fraction: Float, text: String) {
    val g = LocalGlass.current
    val f by animateFloatAsState(
        fraction.coerceIn(0f, 1f),
        spring(dampingRatio = 0.8f, stiffness = 110f),
        label = "ring"
    )
    Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = size.minDimension * 0.1f
            val tl = Offset(sw / 2, sw / 2)
            val sz = Size(size.width - sw, size.height - sw)
            drawArc(
                g.text.copy(alpha = 0.14f), -90f, 360f, false, tl, sz,
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
            drawArc(
                g.accent, -90f, 360f * f, false, tl, sz,
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            GText(text, 15.sp, FontWeight.SemiBold)
            GText(label, 10.sp, color = g.subtext)
        }
    }
}

@Composable
fun DeviceCard(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var bat by remember { mutableIntStateOf(readBattery(ctx)) }
    var ram by remember { mutableFloatStateOf(0f) }
    var disk by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            bat = readBattery(ctx)
            try {
                val mi = ActivityManager.MemoryInfo()
                (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
                if (mi.totalMem > 0) ram = 1f - mi.availMem.toFloat() / mi.totalMem.toFloat()
                val sf = StatFs(Environment.getDataDirectory().path)
                if (sf.totalBytes > 0) disk = 1f - sf.availableBytes.toFloat() / sf.totalBytes.toFloat()
            } catch (_: Exception) {
            }
            delay(4000)
        }
    }
    Row(
        modifier.fillMaxWidth().glass(RoundedCornerShape(30.dp)).padding(vertical = 18.dp, horizontal = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val b = bat.coerceAtLeast(0)
        Ring("Battery", b / 100f, "$b%")
        Ring("RAM", ram, "${(ram * 100).roundToInt()}%")
        Ring("Storage", disk, "${(disk * 100).roundToInt()}%")
    }
}

class NowPlaying(
    val title: String,
    val artist: String,
    val playing: Boolean,
    val art: ImageBitmap?,
    val controller: MediaController,
)

private fun readNowPlaying(ctx: Context): NowPlaying? {
    try {
        val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val sessions = msm.getActiveSessions(ComponentName(ctx, BadgeService::class.java))
        val c = sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: sessions.firstOrNull() ?: return null
        val md = c.metadata ?: return null
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return null
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
        return NowPlaying(title, artist, c.playbackState?.state == PlaybackState.STATE_PLAYING, bmp?.asImageBitmap(), c)
    } catch (_: Exception) {
        return null
    }
}

@Composable
private fun MediaGlyph(kind: Int, color: Color, modifier: Modifier) {
    // kind: 0 previous, 1 play, 2 pause, 3 next
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        when (kind) {
            1 -> drawPath(
                Path().apply {
                    moveTo(w * 0.3f, h * 0.15f); lineTo(w * 0.85f, h * 0.5f); lineTo(w * 0.3f, h * 0.85f); close()
                }, color
            )
            2 -> {
                drawRoundRect(color, Offset(w * 0.22f, h * 0.15f), Size(w * 0.2f, h * 0.7f), CornerRadius(4f))
                drawRoundRect(color, Offset(w * 0.58f, h * 0.15f), Size(w * 0.2f, h * 0.7f), CornerRadius(4f))
            }
            3 -> {
                drawPath(
                    Path().apply {
                        moveTo(w * 0.12f, h * 0.2f); lineTo(w * 0.7f, h * 0.5f); lineTo(w * 0.12f, h * 0.8f); close()
                    }, color
                )
                drawRoundRect(color, Offset(w * 0.76f, h * 0.2f), Size(w * 0.12f, h * 0.6f), CornerRadius(3f))
            }
            else -> {
                drawPath(
                    Path().apply {
                        moveTo(w * 0.88f, h * 0.2f); lineTo(w * 0.3f, h * 0.5f); lineTo(w * 0.88f, h * 0.8f); close()
                    }, color
                )
                drawRoundRect(color, Offset(w * 0.12f, h * 0.2f), Size(w * 0.12f, h * 0.6f), CornerRadius(3f))
            }
        }
    }
}

@Composable
fun MusicCard(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    var np by remember { mutableStateOf<NowPlaying?>(null) }
    var enabled by remember { mutableStateOf(listenerEnabled(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            enabled = listenerEnabled(ctx)
            val fresh = if (enabled) withContext(Dispatchers.Default) { readNowPlaying(ctx) } else null
            val old = np
            if (fresh == null || old == null || old.title != fresh.title || old.playing != fresh.playing) np = fresh
            delay(1500)
        }
    }
    Column(
        modifier.fillMaxWidth().glass(RoundedCornerShape(30.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        GText("NOW PLAYING", 12.sp, FontWeight.SemiBold, color = g.accent, letterSpacing = 1.4.sp)
        val n = np
        when {
            !enabled -> {
                GText("Allow notification access to see and control your music here.", 13.sp, color = g.subtext, maxLines = 3)
                Row {
                    GChip("Allow access", true) {
                        openSystemScreen(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    }
                }
            }
            n == null -> GText("Nothing playing right now.", 14.sp, color = g.subtext)
            else -> Row(verticalAlignment = Alignment.CenterVertically) {
                if (n.art != null) {
                    Image(
                        n.art, null,
                        Modifier.size(58.dp).clip(RoundedCornerShape(16.dp)),
                        contentScale = ContentScale.Crop,
                    )
                    Spacer(Modifier.width(12.dp))
                }
                Column(Modifier.weight(1f)) {
                    GText(n.title, 16.sp, FontWeight.SemiBold)
                    GText(n.artist, 13.sp, color = g.subtext)
                }
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.size(34.dp).springClick { try { n.controller.transportControls.skipToPrevious() } catch (_: Exception) {} },
                    contentAlignment = Alignment.Center
                ) { MediaGlyph(0, g.text, Modifier.size(20.dp)) }
                Box(
                    Modifier.size(40.dp).springClick {
                        try {
                            if (n.playing) n.controller.transportControls.pause()
                            else n.controller.transportControls.play()
                        } catch (_: Exception) {
                        }
                    },
                    contentAlignment = Alignment.Center
                ) { MediaGlyph(if (n.playing) 2 else 1, g.text, Modifier.size(26.dp)) }
                Box(
                    Modifier.size(34.dp).springClick { try { n.controller.transportControls.skipToNext() } catch (_: Exception) {} },
                    contentAlignment = Alignment.Center
                ) { MediaGlyph(3, g.text, Modifier.size(20.dp)) }
            }
        }
    }
}

@Composable
fun GameShelf(vm: LauncherViewModel, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val g = LocalGlass.current
    val prefs = vm.prefs
    val games = remember(vm.visibleApps, prefs.games) {
        vm.visibleApps.filter { it.category == AppCategory.Games || it.pkg in prefs.games }
    }
    var usage by remember { mutableStateOf<Map<String, Long>>(emptyMap()) }
    var access by remember { mutableStateOf(hasUsageAccess(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            access = hasUsageAccess(ctx)
            if (access) usage = withContext(Dispatchers.IO) { weeklyUsage(ctx) }
            delay(15_000)
        }
    }
    val sorted = remember(games, usage) { games.sortedByDescending { usage[it.pkg] ?: 0L } }

    Column(
        modifier.fillMaxWidth().glass(RoundedCornerShape(30.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        GText("GAME SHELF", 12.sp, FontWeight.SemiBold, color = g.accent, letterSpacing = 1.4.sp)
        if (sorted.isEmpty()) {
            GText(
                "No games found yet. Long-press any app and choose \"Add to game shelf\".",
                13.sp, color = g.subtext, maxLines = 3,
            )
        } else {
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                sorted.take(12).forEach { e ->
                    AppCell(
                        e, prefs, true,
                        onLongClick = { vm.menu = e },
                        subtitle = usage[e.pkg]?.let { fmtPlaytime(it) },
                    )
                }
            }
        }
        if (!access) {
            Row {
                GChip("Show weekly playtime", false) {
                    openSystemScreen(ctx, Settings.ACTION_USAGE_ACCESS_SETTINGS)
                }
            }
        }
    }
}

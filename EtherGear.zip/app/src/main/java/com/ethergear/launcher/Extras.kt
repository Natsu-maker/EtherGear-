package com.ethergear.launcher

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Rename dialog for an app's label (long-press menu, "Rename"). */
@Composable
fun RenameDialog(vm: LauncherViewModel) {
    val e = vm.renaming ?: return
    val g = LocalGlass.current
    var text by remember(e.pkg) { mutableStateOf(e.label) }

    fun save(v: String?) {
        vm.prefs.updateLabel(e.pkg, v)
        e.label = vm.prefs.customLabels[e.pkg] ?: e.systemLabel
        vm.renaming = null
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.6f))
            .pointerInput(Unit) { detectTapGestures { vm.renaming = null } },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .padding(28.dp)
                .widthIn(max = 360.dp)
                .glass(RoundedCornerShape(30.dp))
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            GText("Rename ${e.systemLabel}", 18.sp, FontWeight.SemiBold, maxLines = 2)
            BasicTextField(
                value = text,
                onValueChange = { text = it.take(24) },
                singleLine = true,
                textStyle = TextStyle(color = g.text, fontSize = 18.sp, fontFamily = LocalFont.current),
                cursorBrush = SolidColor(g.accent),
                modifier = Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).padding(14.dp),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GChip("Reset", false) { save(null) }
                GChip("Save", true) { save(text) }
            }
        }
    }
}

package com.ethergear.launcher

import android.app.Application
import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.util.Date

/** Saves the last crash to a file so it can be read in Settings and sent for fixing. */
object CrashLog {
    private var installed = false

    private fun file(ctx: Context) = File(ctx.filesDir, "crash.txt")

    fun install(app: Application) {
        if (installed) return
        installed = true
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                file(app).writeText("${Date()}\nthread: ${t.name}\n$sw".take(8000))
            } catch (_: Throwable) {
            }
            prev?.uncaughtException(t, e)
        }
    }

    fun read(ctx: Context): String? = try {
        file(ctx).takeIf { it.exists() }?.readText()
    } catch (_: Throwable) {
        null
    }

    fun clear(ctx: Context) {
        try {
            file(ctx).delete()
        } catch (_: Throwable) {
        }
    }
}
